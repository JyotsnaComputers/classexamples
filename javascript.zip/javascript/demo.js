var mvar = 100
let lvar = 200
console.log("Hello world")
console.log("var " + mvar)
console.log("let " + lvar)

