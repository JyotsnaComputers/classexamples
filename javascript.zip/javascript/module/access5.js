import {hello, other} from "./module5.js"; 

hello();

other();