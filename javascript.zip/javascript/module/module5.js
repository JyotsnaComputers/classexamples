function hello() {
    console.log("Hello Module");
}

function other(){
    console.log("another function ");
    nonexport();
}
 
function nonexport(){
    console.log("Not exported");
}

export {hello, other}