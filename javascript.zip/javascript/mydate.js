function printDetails(givenDate) {

var day = givenDate.getDate();
var month = givenDate.getMonth();
var monthName;
	
var hours = givenDate.getHours(); 
var mins = givenDate.getMinutes(); 
var secs = givenDate.getSeconds(); 
var strToAppend;
if (hours >12 )
{
    strToAppend = "PM";
}
else if (hours <12)
{
	strToAppend = "AM";
}
	
if(mins<10)
mins = "0" + mins;
if (secs<10)
	secs = "0" + secs;

switch (month)
{
	case 0:
		monthName = "January";
		break;
	case 1:
		monthName = "February";
		break;
	case 2:
		monthName = "March";
		break;
	case 3:
		monthName = "April";
		break;
	case 4:
		monthName = "May";
		break;
	case 5:
		monthName = "June";
		break;
	case 6:
		monthName = "July";
		break;
	case 7:
		monthName = "August";
		break;
	case 8:
		monthName = "September";
		break;
	case 9:
		monthName = "October";
		break;
	case 10:
		monthName = "November";
		break;
	case 11:
		monthName = "December";
		break;
}

var year = givenDate.getFullYear();
var myString;
myString = "Given Date is " + day +  " - " + monthName + " - " + year + ".<br />Given time is " + hours + ":" + mins + ":" + secs + " " + strToAppend + ".";
document.write("<h2>"+myString +"</h2>");
    
}