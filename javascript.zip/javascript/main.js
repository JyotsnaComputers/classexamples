"use strict";

// myVar = 10; // myVar is not defined
// console.log(myVar);

// myVar = "string"; 
var myVar = "mystring";
console.log(myVar);


var emp = {id:10, name:'Siva'};
// emp = {id:10, name:'Siva'}; // emp is not defined
console.log(emp);

function fun(f1, f2) {}; // Duplicate parameter name not allowed in this context
