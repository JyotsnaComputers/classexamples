package com.cg.eis.exception;

public class Implimentation {
	void checkSalary(Employee emp) throws EmployeeException {
		if(emp.getSalary() < 3000) {
			throw new EmployeeException();
		}
	}
}