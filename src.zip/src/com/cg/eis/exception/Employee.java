package com.cg.eis.exception;

public class Employee {
	public Employee(double salary) {
		super();
		this.salary = salary;
	}
	private double salary;
	
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
}
