package regx;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExample12 {

	public static void main(String[] args) {
		// The appendReplacement and appendTail Methods
		String REGEX = "a*b";
		String INPUT = "aabfooaaabfooabfoob";
		String REPLACE = "-";


		Pattern p = Pattern.compile(REGEX);

		// get a matcher object
		Matcher m = p.matcher(INPUT);
		StringBuffer sb = new StringBuffer();
		while(m.find()) {
			m.appendReplacement(sb, REPLACE);
		}
		m.appendTail(sb);
		System.out.println(sb.toString());
		
		
	}

}
