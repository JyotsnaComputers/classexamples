package regx;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExample11 {

	public static void main(String[] args) {
		// The replaceFirst and replaceAll Methods
			String REGEX = "dog";
			String INPUT = "The dog says meow. " + "All dogs say meow.";
			String REPLACE = "cat";

			Pattern p = Pattern.compile(REGEX);

			// get a matcher object
			Matcher m = p.matcher(INPUT); 
			INPUT = m.replaceAll(REPLACE);
			System.out.println(INPUT);
		}

	}
