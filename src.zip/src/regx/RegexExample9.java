package regx;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExample9 {

	public static void main(String[] args) {
		//The start and end Methods
		String REGEX = "\\bcat\\b";
		String INPUT = "cat cat cat cattie cat";
		Pattern p = Pattern.compile(REGEX);
		Matcher m = p.matcher(INPUT);   // get a matcher object
		int count = 0;

		while(m.find()) {
			count++;
			System.out.print("Match number "+count);
			System.out.print("\tstart(): "+m.start());
			System.out.println("\tend(): "+m.end());
		}
	}
}