package regx;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValdation {

	public static void main(String[] args) {
		//^[a-zA-Z0-9_!#$%&�*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$
		System.out.println("Enter your mail id ");
		Scanner scanner = new Scanner(System.in);

		String email = scanner.next();

		scanner.close();

		Pattern pattern = Pattern.compile("^[a-zA-Z0-9_!#$%&�*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$");
		Matcher matcher = pattern.matcher(email);
		System.out.println(email +" : "+ matcher.matches());

	}
}