package java8;

public class StaticReferenceDemo {
	public static int add(int num1, int num2) {
		return num1 + num2;
	}

	public static int mul(int num1, int num2) {
		return num1 * num2;
	}

	public static void main(String[] args) {
		Caluculate iref = StaticReferenceDemo::add;
		System.out.println(iref.cal(4, 5));

		iref = StaticReferenceDemo::mul;
		System.out.println(iref.cal(4, 5));

	}
}