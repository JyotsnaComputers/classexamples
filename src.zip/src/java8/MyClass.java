package java8;

public class MyClass implements MyInterface {

	@Override
	public double doubleIt(double num) {
		// TODO Auto-generated method stub
		return 0;
	}

}
