package java8;

public class MultipleInterfaceImplementationDemo extends SomeClass implements MyInterfaceTwo, MyInterfaceThree {

	public void method() {
	}

	public static void main(String[] args) {
		MultipleInterfaceImplementationDemo obj = new MultipleInterfaceImplementationDemo();
		SomeClass.statMethod();
		MyInterfaceTwo.statMethod();
	}

}
