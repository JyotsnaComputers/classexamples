package java8;

public class SomeClass {
	public static void statMethod() {
		System.out.println("Some Class Static Method ");
	}
}