package java8;

@FunctionalInterface
public interface MyInterfaceOne {
	public abstract int method(String arg);

	public default void implementedMethod1() {
//		System.out.println("Method implemented in Interface ");
	}

	public default void implementedMethod2() {
//		System.out.println("Method implemented in Interface ");
	}

	public default void implementedMethod3() {
//		System.out.println("Method implemented in Interface ");
	}
}