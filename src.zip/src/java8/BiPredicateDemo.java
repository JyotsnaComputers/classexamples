package java8;

import java.util.function.BiPredicate;

public class BiPredicateDemo {

	public static void main(String[] args) {
		BiPredicate<Double, Float> check = (dnum, fnum) -> dnum > fnum;
		System.out.println(check.test(4.5, 3.14f));

		BiPredicate<Employee, Gender> checkSalGen = (emp, gen) -> (emp.getSalary() > 30000) && (emp.getGender() == gen);

		Employee empObj = new Employee(1, Gender.FEMALE, 40000);
		Gender gen = Gender.MALE;

		System.out.println(checkSalGen.test(empObj, gen));
	}

}
