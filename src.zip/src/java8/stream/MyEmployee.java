package java8.stream;

import java.util.Comparator;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class MyEmployee implements Comparable<MyEmployee>{
	private int eid;
	private String ename;
	private Gender gender;
	private int age;
	@Override
	public int compareTo(MyEmployee emp) {
		
		return this.getAge() - emp.getAge();
	}
	
}