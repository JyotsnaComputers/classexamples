package java8.stream;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamsDemo01 {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(23, 45, 32, 65, 74, 36, 52, 46, 38, 49);

		Stream<Integer> myStream = list.stream();
		Stream<Integer> sortedStream = myStream.sorted();
		Stream<Integer> giveFive = sortedStream.limit(5);
		giveFive.forEach(System.out::println);

		list.stream().sorted().limit(5).forEach(System.out::println);

		List<Integer> sorted = list.stream().sorted().limit(5).collect(Collectors.toList());
		System.out.println(sorted);

		MyEmployee[] empArr = { new MyEmployee(1, "Shiva", Gender.MALE, 20),
				new MyEmployee(3, "Gayatri", Gender.FEMALE, 35), new MyEmployee(4, "Ramesh", Gender.MALE, 32),
				new MyEmployee(6, "Rama", Gender.FEMALE, 19), new MyEmployee(7, "Chandra", Gender.MALE, 54),
				new MyEmployee(8, "Ragini", Gender.FEMALE, 42) };

		List<MyEmployee> empList = Arrays.asList(empArr);
//
//		empList.sort((e1, e2) -> e1.getEname().compareTo(e2.getEname()));
//
//		empList.stream().forEach(System.out::println);

//		// Prints list elements
//		empList.stream().forEach(System.out::println);
//
//		// prints sorted elements on age [as implemented in Employee class by Comparable
//		System.out.println("************");
//		empList.stream().sorted().forEach(System.out::println);
//
//		System.out.println("##########");
//		// prints sorted elements on Ename
//		empList.stream().sorted((emp1, emp2) -> emp1.getEname().compareTo(emp2.getEname()))
//				.forEach(System.out::println);
//		System.out.println("&&&&&&&&&&");

//		empList.stream().sorted((e1, e2) -> e2.getEname().compareToIgnoreCase(e1.getEname()))
//				.filter(emp -> emp.getAge() > 20 && emp.getAge() < 50).forEach(System.out::println);

//		System.out.println("************");
//
//		empList.stream().forEach(System.out::println);

		System.out.println("@@@@@@@@@");
		Stream<MyEmployee> empStream = Stream.of(new MyEmployee(1, "Shiva", Gender.MALE, 20),
				new MyEmployee(3, "Gayatri", Gender.FEMALE, 35), new MyEmployee(4, "Ramesh", Gender.MALE, 32),
				new MyEmployee(6, "Rama", Gender.FEMALE, 19), new MyEmployee(7, "Chandra", Gender.MALE, 54),
				new MyEmployee(8, "Ragini", Gender.FEMALE, 42));

		System.out.println(empStream.count());
		Predicate<MyEmployee> pred = (emp) -> emp.getAge() > 20;
		empStream.filter(pred).forEach(System.out::println);
	}
}