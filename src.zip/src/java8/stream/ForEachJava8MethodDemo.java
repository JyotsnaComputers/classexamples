package java8.stream;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
class Employee{
	private int empId;
	private String fullName;
}
public class ForEachJava8MethodDemo {

	public static void main(String[] args) {
		List<Employee> list = new ArrayList<Employee>();
		list.add(new Employee(1, "Rajesh"));
		list.add(new Employee(2, "Ramesh"));
		list.add(new Employee(3, "Suresh"));
		list.add(new Employee(4, "Deepesh"));
		list.add(new Employee(5, "Mahesh"));
		
		list.forEach(emp->System.out.println(emp));
		System.out.println("**************");
		list.forEach(System.out::println);
	}
}