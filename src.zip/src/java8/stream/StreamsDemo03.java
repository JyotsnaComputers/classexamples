package java8.stream;

import java.util.stream.Stream;

public class StreamsDemo03 {

	public static void main(String[] args) {
		// Stream.of()
//		Stream<Integer> stream1 = Stream.of(1,2,3,4,5,6,7,8,9);
//		stream1.forEach(num -> System.out.print(num + " "));
//		System.out.println();

//		// Stream.of(array)
//		Stream<Integer> stream2 = Stream.of(new Integer[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 });
//		stream2.forEach(p -> System.out.print(p + " "));
//		System.out.println();

//		// Stream.generate()
//		Stream<Integer> intStream = Stream.generate(() -> 1).limit(3);
//		intStream.forEach(System.out::println);
//
//		Stream.generate(() -> new Random().nextInt(100)).limit(5).forEach(num -> System.out.print(num + " "));
//		System.out.println();

		// Stream.iterate()
		Stream.iterate(3, i -> i * 2).limit(10).forEach(num -> System.out.print(num + " "));
		System.out.println();

	}

}
