package java8.stream;

public enum Gender {
	MALE, FEMALE, OTHERS;
}