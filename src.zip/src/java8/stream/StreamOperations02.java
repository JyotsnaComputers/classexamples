package java8.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class StreamOperations02 {

	public static void main(String[] args) {
//		Collecting Stream elements to an Array
//		List<Integer> list = Arrays.asList(23, 45, 32, 65, 74, 36, 74, 65, 52, 46, 32, 38, 49);
//		Integer arr[] = list.stream().sorted(Collections.reverseOrder()).limit(5).toArray(Integer[]::new);
//		for (Integer temp : arr) {
//			System.out.print(temp + "\t");
//		}
//		System.out.println();
//		System.out.println("************");
//		list.stream().sorted(Collections.reverseOrder()).limit(5).sorted()
//				.forEach(element -> System.out.print(element + "\t"));
//		System.out.println();
//		Collecting Stream elements to List
//		List<Integer> list = Arrays.asList(23, 45, 32, 65, 74, 36, 74, 65, 52, 46, 32, 38, 49);
//		List<Integer> iLst = list.stream()
//							.sorted(Collections.reverseOrder())
//							.limit(5)
//							.collect(Collectors.toList());
//		System.out.println(iLst.toString());
//		Collecting Stream elements to Set	
//		Set<Integer> set = list.stream().sorted(Collections.reverseOrder()).collect(Collectors.toSet());
//		set.stream().sorted().forEach(element -> System.out.print(element + " "));
//		System.out.println();

//////		//min
//		List<Integer> list = Arrays.asList(23, 45, 32, 65, 74, 36, 74, 65, 52, 46, 32, 38, 49);
//		Optional<Integer> minNumber = list.stream().min((i, j) -> i.compareTo(j));
//		minNumber.ifPresent(System.out::println);
//
////		//max
//		Optional<Integer> maxNumber = list.stream().max((i, j) -> i.compareTo(j));
//		maxNumber.ifPresent(System.out::println);
//
////		//peek
//		List<Integer> nums = list.stream().filter(num -> num > 50).peek(e ->{ e *= 10; System.out.println(e);}).collect(Collectors.toList());
//		System.out.println("Peek" + nums);
//		
//		//distinct
//		Arrays.asList(2, 5, 2, 5, 4, 3, 2, 6, 8, 9).stream().distinct().forEach(num -> System.out.print(num + " "));
//		System.out.println();
		// Stream operations
		List<String> lstNames = new ArrayList<>();
		lstNames.add("Kavin");
		lstNames.add("Megha");
		lstNames.add("Shivam");
		lstNames.add("Bharath");
		lstNames.add("Vidya");
		lstNames.add("Ronit");
		lstNames.add("Rohit");
		lstNames.add("Anurag");
		lstNames.add("Suyog");
		lstNames.add("Vishal");
		lstNames.add("Adesh");
		lstNames.add("Pratibha");

////		//filter
//		lstNames.stream()
//			.filter((s) -> s.startsWith("A"))
//			.forEach(System.out::println);
//		
//		//map
//		lstNames.stream().filter((s) -> s.startsWith("A")).map(String::toUpperCase)// str -> str.toUpperCase()
//				.forEach(System.out::println);

//		//sorted
//		lstNames.stream().sorted().
//			limit(5).forEach(System.out::println);
//		
//		//collect
//		List<String> nList = lstNames.stream().sorted()
//        .map(String::toUpperCase).limit(4)
//        .collect(Collectors.toList());
//		System.out.println(nList);
//		
		// match
		boolean found = lstNames.stream().anyMatch((s) -> s.startsWith("K"));
		System.out.println(found);

		found = lstNames.stream().allMatch((s) -> s.contains("a"));
		System.out.println(found);

		found = lstNames.stream().noneMatch((s) -> s.startsWith("Z"));
		System.out.println(found);
//		
		// reduce
		Optional<String> joined = lstNames.stream().filter(name -> !(name.contains("a"))).sorted().limit(4)
				.reduce((s1, s2) -> s1 + "-" + s2);
		joined.ifPresent(System.out::println);

		// find First
		Optional<String> first = lstNames.stream().filter((s) -> s.startsWith("Z")).findFirst();
		if (first.isPresent())
			System.out.println(first.get());
		else
			System.out.println("Not starting with 'Z' ");

//		// find Any
		Optional<String> findAny = lstNames.stream().filter((s) -> s.contains("a")).findAny();

		if (findAny.isPresent())
			System.out.println(findAny.get());
		else
			System.out.println("Not found any contains- 'c' ");
	}
}