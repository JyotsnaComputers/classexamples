package java8.stream;

import java.util.Collections;
import java.util.IntSummaryStatistics;
import java.util.stream.IntStream;

public class PremitiveStreamsDemo {

	public static void main(String[] args) {
		int arr[] = new int[] {76,45,12,43,23,56,63,47,35};
//
		System.out.println("Min : " + IntStream.of(arr).min().getAsInt());
		System.out.println("Max : " + IntStream.of(arr).max().getAsInt());
		
		IntStream.of(arr).sorted().forEach(num -> System.out.print(num + " "));
		System.out.println();
		IntStream.of(arr).sorted().limit(4). forEach(num -> System.out.print(num + " "));
		System.out.println();
		System.out.println("Sum : " + IntStream.of(arr).sum());
		System.out.println(IntStream.of(arr).min().getAsInt());
		
		
		IntSummaryStatistics stats = IntStream.of(arr).summaryStatistics();
		
		arr = new int[] {4,2,7,3,9};
		
		System.out.println(stats.getAverage());
		System.out.println(stats.getCount());
		System.out.println(stats.getMax());
		System.out.println(stats.getMin());
		System.out.println(stats.getSum());
		
	}
}