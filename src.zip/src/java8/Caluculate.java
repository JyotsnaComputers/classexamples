package java8;

public interface Caluculate {
	int cal(int num1, int num2);
}