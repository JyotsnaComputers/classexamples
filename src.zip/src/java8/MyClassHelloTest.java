package java8;

public class MyClassHelloTest {

	public static void main(String[] args) {
		MyClassHello hello = new MyClassHello();

		MyInterface mi = hello::wish;
		statMethod(mi);
	}

	static void statMethod(MyInterface mi) {
		mi.sayHello("Concentrix ");
	}
}