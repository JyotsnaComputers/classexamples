package java8;

public class MyInterfaceObjectDemo {

	public static void main(String[] args) {
		MyInterface iObj = new MyClass();
		MyInterface iref = (num) -> num * 2;
		System.out.println(iref.doubleIt(10));

		MyInterface iref2 = (num) -> {
			double result = 0;
			result += num;
			result += num;

			return result;
		};
		System.out.println(iref.doubleIt(10));

		FunctionalInterfaceUser fiObj = (myStr) -> "Hello " + myStr;

	}

}
