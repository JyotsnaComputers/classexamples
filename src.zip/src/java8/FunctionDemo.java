package java8;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;

public class FunctionDemo {

	public static void main(String[] args) {
		Function<List<Employee>, Employee> highSalary = (employees) -> {
			Iterator<Employee> empItr = employees.iterator();
			double max = 0;
			Employee emp = null;
			while (empItr.hasNext()) {
				Employee empObj = empItr.next();
				if (max < empObj.getSalary()) {
					max = empObj.getSalary();
					emp = empObj;
				}
			}

			return emp;
		};

		List<Employee> empList = new ArrayList<Employee>();

		empList.add(new Employee(1, Gender.FEMALE, 32000));
		empList.add(new Employee(2, Gender.FEMALE, 33000));
		empList.add(new Employee(3, Gender.MALE, 33500));
		empList.add(new Employee(8, Gender.FEMALE, 34000));
		empList.add(new Employee(6, Gender.MALE, 31000));
		empList.add(new Employee(5, Gender.FEMALE, 32000));
		empList.add(new Employee(4, Gender.MALE, 33700));

		Function<Employee, Gender> getGen = (emp) -> emp.getGender();

		Employee highSalariedEmployee = highSalary.apply(empList);

		System.out.println(highSalariedEmployee);
//		

		Gender gen = highSalary.andThen(getGen).apply(empList);

		System.out.println(gen);
	}
}