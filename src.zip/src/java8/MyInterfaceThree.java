package java8;

public interface MyInterfaceThree {

	public abstract void method();

	public static void statMethod() {
		System.out.println("Interface Static Three Method ");
	}
}