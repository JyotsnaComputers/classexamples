package java8;

@FunctionalInterface
interface FunctionalDemo {
	void method();
}

public class LamdaExpressionDemo {
	public static void main(String[] args) {
		int local = 50;
		FunctionalDemo ac = new FunctionalDemo() {
			@Override
			public void method() {
				System.out.println("A C Demo " + local);
			}
		};
		FunctionalDemo fd = () -> {
			System.out.println("F I Demo " + local);
		};

		ac.method();
		fd.method();

	}
}