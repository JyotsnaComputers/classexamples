package java8;

@FunctionalInterface
public interface MyInterface {
	double doubleIt(double num);
}