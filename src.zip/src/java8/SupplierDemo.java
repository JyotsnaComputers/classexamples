package java8;

import java.util.function.Supplier;

public class SupplierDemo {

	public static void main(String[] args) {
		Supplier<String> message = () -> "Hello Concentrix ";

		Supplier<Employee> empSupplier = () -> new Employee();

		System.out.println(message.get());

	}
}