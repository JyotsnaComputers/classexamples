package java8;

import java.util.function.Predicate;

public class PredicateDemo {

	public static void main(String[] args) {
		Predicate<Integer> odd = (num) -> num % 2 != 1;

		Employee empObj = new Employee(10, Gender.MALE, 30000);

		System.out.println(odd.test(26));

		Predicate<Employee> maleEmp = (emp) -> emp.getGender() == Gender.MALE;

		System.out.println(maleEmp.test(empObj));

		System.out.println(maleEmp.negate().test(empObj));

		Predicate<Employee> checkSal = (emp) -> emp.getSalary() < 30000;

		System.out.println(checkSal.test(empObj));

		System.out.println(checkSal.and(maleEmp).test(empObj));

		System.out.println(checkSal.or(maleEmp).test(empObj));
	}
}