package java8;

import java.util.function.BiConsumer;

public class BiComsumerDemo {

	public static void main(String[] args) {
		BiConsumer<Employee, Student> print = (emp, stu) -> {
			System.out.println("Employee " + emp);
			System.out.println("Student " + stu);
		};

		print.accept(new Employee(3, Gender.FEMALE, 54100), new Student(46));

		BiConsumer<Student, Student> compare = (stu1, stu2) -> {
			if (stu1.getMarks() > stu2.getMarks()) {
				System.out.println("Student stu1 got Highet marks");
			} else {
				System.out.println("Student stu2 got Highet marks");
			}
		};

		print.accept(new Employee(3, Gender.FEMALE, 54100), new Student(46));

	}

}
