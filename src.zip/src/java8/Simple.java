package java8;

public class Simple {
	public static void statMethod() {
		System.out.println("Simple Static Method ");
	}
}