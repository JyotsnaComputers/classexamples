package java8;

interface SomeInter {
	Employee getObject(int num);
}

public class ConstructorRefeneceDemo {

	public static void main(String[] args) {

		SomeInter ref = Employee::new;

		Employee eobj = ref.getObject(10);

		System.out.println(eobj.getData());
	}
}