package java8;

public interface MyInterfaceTwo {

	public abstract void method();

	public static void statMethod() {
		System.out.println("Interface Static Two Method ");
	}
}