package java8;

import java.util.function.Consumer;

public class ConsumerDemo {

	public static void main(String[] args) {
		Consumer<Employee> show = (emp) -> System.out.println(emp);

		Consumer<Employee> showmale = (emp) -> {
			if (emp.getGender() == Gender.MALE)
				System.out.println(emp.getSalary());
		};

		Employee empObj1 = new Employee(1, Gender.FEMALE, 35600);
		show.accept(empObj1);

		Employee empObj2 = new Employee(4, Gender.MALE, 33700);
		showmale.accept(empObj2);

		show.andThen(showmale).accept(empObj2);
	}
}