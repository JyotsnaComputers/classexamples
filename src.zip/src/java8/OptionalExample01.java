package java8;

import java.util.Optional;

public class OptionalExample01 {
	public static void main(String[] args) {
		String[] strArr = new String[5];
		strArr[2] = new String("Concentrix");
//		System.out.println(strArr[4].toLowerCase());

		Optional<String> checkNull = Optional.ofNullable(strArr[2]);

//		if (checkNull.isPresent()) {
//			System.out.println(checkNull.get());
//		} else {
//			System.out.println("It's Null ");
//		}
		System.out.println(checkNull.orElse("It's Optional null "));

	}
}
