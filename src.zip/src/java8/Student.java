package java8;

public class Student {

	private int marks;

	public Student() {

	}

	public Student(int marks) {
		this.marks = marks;
	}

	void stuSimple() {
		System.out.println("Student Data");
		System.out.println("Data value " + marks);
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}
}