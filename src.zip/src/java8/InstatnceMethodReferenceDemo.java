package java8;

import java.util.Arrays;

public class InstatnceMethodReferenceDemo {
	public static void main(String[] args) {
		String[] strArr = { "One", "Two", "ten", "once", "Three", "Four", "Five", "Six" };

		Arrays.sort(strArr, String::compareToIgnoreCase);

		for (String str : strArr) {
			System.out.print(str + "\t");
		}
	}
}