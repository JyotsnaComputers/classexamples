package java8;

@FunctionalInterface
public interface FunctionalInterfaceUser {

	String sayHello(String str);

//	String toString();
//
//	int hashCode();
//	
//	boolean equals(Object obj);
}