package java8;

public class ImplementedClass {//implements MyInterfaceOne {

	
	public void method() {
		System.out.println("Implented Method ");
	}

//	public void definedMethod() {
//		System.out.println("New Method");
//	}
}