package java8;

class MyInterfaceOneImpl implements MyInterfaceOne {

	@Override
	public int method(String str) {

		return str.length();
	}

}

public class InterfaceDemo {

	public static void main(String[] args) {

	}
}