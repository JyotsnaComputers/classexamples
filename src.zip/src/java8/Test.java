package java8;

public class Test {

	public static void main(String[] args) {
		
	}
}