package java8.datetime;

import java.time.LocalDate;
import java.time.Period;

public class PeriodDemo {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		LocalDate specific = LocalDate.of(1980, 3, 29);
		
		Period period = Period.between(specific, today);
		
		System.out.println(period.getYears());
		System.out.println(period.getMonths());
		System.out.println(period.getDays());
		
		System.out.println(period);

	}
}