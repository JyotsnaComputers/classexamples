package java8.datetime;

import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.ChronoField;

//import java.util.Date;

public class DateDemo {

	public static void main(String[] args) {
//		Date today = new Date();
//		System.out.println(today);
		
		LocalDate today = LocalDate.now();
		System.out.println(today);
		
		LocalDate specific = LocalDate.of(1980, 8, 25);
		System.out.println(specific);
		
		LocalDate republicDay = LocalDate.of(1950, Month.JANUARY, 26);
		System.out.println(republicDay);
		
		System.out.println(today.compareTo(republicDay));
		System.out.println(specific.getDayOfYear());
		System.out.println(specific.getDayOfMonth());
		
		System.out.println(today.isLeapYear());
		System.out.println(specific.isLeapYear());
		System.out.println(republicDay.isLeapYear());
		
		System.out.println(today.minusDays(10));
		System.out.println(today.plusDays(-10));
		System.out.println(today.minusDays(-10));
		System.out.println(today.plusDays(10));
		
		LocalDate findDate = LocalDate.ofYearDay(2022, 100);
		System.out.println(findDate);
		
	}
}