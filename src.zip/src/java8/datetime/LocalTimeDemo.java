package java8.datetime;

import java.time.LocalTime;

public class LocalTimeDemo {

	public static void main(String[] args) {
		LocalTime ctime = LocalTime.now();
		System.out.println(ctime);
		
		LocalTime stime1 = LocalTime.of(10,20);
		System.out.println(stime1);
		
		LocalTime stime2 = LocalTime.of(10,20,40);
		System.out.println(stime2);
		
		LocalTime stime3 = LocalTime.of(10,20,40,65432);
		System.out.println(stime3);
		
		System.out.println(stime3.plusMinutes(810));
		
		
		System.out.println(ctime.plusHours(100));
		
		System.out.println(ctime.minusHours(-12));
		

	}
}