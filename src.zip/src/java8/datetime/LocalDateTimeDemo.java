package java8.datetime;

import java.time.LocalDateTime;
import java.time.LocalTime;

public class LocalDateTimeDemo {

	public static void main(String[] args) {
//		LocalDateTime present = LocalDateTime.now();
//		System.out.println(present);

//		LocalDate today = LocalDate.now();
//		LocalDate specificDate1 = LocalDate.of(1980, 8, 25);
//		LocalDate specificDate2 = LocalDate.of(2012, Month.MAY, 10);
//		System.out.println("Today " + today);
//		System.out.println("1980 " + specificDate1);
//		System.out.println("2010 " + specificDate2);
//
//		System.out.println("Day of Month " + today.getDayOfMonth());
//
//		System.out.println("Day of Year " + today.getDayOfYear());
//
//		System.out.println("Month name " + today.getMonth());
//		System.out.println("Month Number " + today.getMonthValue());
//
//		System.out.println(specificDate1.isBefore(specificDate2));
//
//		System.out.println("Leap Year  " + specificDate2.isLeapYear());
//
//		LocalDate tenDaysBefore = today.minusDays(50);
//		System.out.println("Ten days Before " + tenDaysBefore);
//
//		tenDaysBefore = today.minusDays(-50);
//		System.out.println("Ten days After " + tenDaysBefore);

		LocalTime currentTime = LocalTime.now();
		LocalTime specificTime = LocalTime.of(10, 20, 40, 65432);

		LocalDateTime now = LocalDateTime.now();

		System.out.println(now.toString());
//		LocalDateTime specificDateTime2 = LocalDateTime.of(1972, 6, 6, 9, 40);
//		System.out.println(specificDateTime2);
//
//		LocalDateTime specificDateTime3 = LocalDateTime.of(1972, 6, 6, 9, 40, 22);
//		System.out.println(specificDateTime3);
//
//		LocalDateTime specificDateTime4 = LocalDateTime.of(1972, 6, 6, 9, 40, 22, 54326);
//		System.out.println(specificDateTime4);

//		System.out.println(sdt2.isAfter(sdt4));

	}
}