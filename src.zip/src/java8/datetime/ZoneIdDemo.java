package java8.datetime;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Iterator;
import java.util.Set;

public class ZoneIdDemo {

	public static void main(String[] args) {
		ZoneId zone = ZoneId.systemDefault();
		System.out.println(zone);

		Set<String> zones = ZoneId.getAvailableZoneIds();
		
		System.out.println(zones.size());
//		Iterator<String> itrZone = zones.iterator();
//		while(itrZone.hasNext()) {
//			System.out.println(itrZone.next());
//		}
		
		ZoneId austime = ZoneId.of("Australia/ACT");
		LocalDateTime cdt = LocalDateTime.now(austime); 
		System.out.println(cdt);
		
		ZonedDateTime szdt = ZonedDateTime.of(1972,6,6,9,40,22,54326,austime);
		
		System.out.println(szdt);
		
	}
}