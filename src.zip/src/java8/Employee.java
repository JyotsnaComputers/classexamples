package java8;

enum Gender {
	MALE, FEMALE, ORHTER
}

public class Employee {

	public Employee(int data) {
		this.data = data;
	}

	public Employee(int data, Gender gender, double salary) {
		super();
		this.data = data;
		this.gender = gender;
		this.salary = salary;
	}

	private int data;
	private Gender gender;
	private double salary;

	public Gender getGender() {
		return gender;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Employee() {

	}

	void empSimple() {
		System.out.println("Employee Data ");
		System.out.println("Data value " + data);
	}

	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "Employee [data=" + data + ", gender=" + gender + ", salary=" + salary + "]";
	}

}