package java8;

import java.util.function.BiFunction;

public class BiFunctionDemo {

	public static void main(String[] args) {
		BiFunction<Double, Float, Boolean> greatest = (num1, num2) -> num1 > num2;

		BiFunction<Employee, Student, User> doSomething = (emp, stu) -> {
			User user = new User();
			user.setId(stu.getMarks());
			user.setGen(emp.getGender());
			return user;
		};

	}

}
