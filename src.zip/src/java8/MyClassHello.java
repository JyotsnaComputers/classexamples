package java8;

public class MyClassHello {
	public String wish(String name) {
		return "Hello " + name;
	}
}