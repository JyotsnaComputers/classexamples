package java8;

import java.util.ArrayList;
import java.util.List;

public class ForEachDemo {

	public static void main(String[] args) {
		List<Employee> list = new ArrayList<Employee>();
		list.add(new Employee(1));
		list.add(new Employee(2));
		list.add(new Employee(3));
		list.add(new Employee(4));
		list.add(new Employee(5));
//		list.forEach(element -> System.out.println(element));
		list.forEach(System.out::println);

	}

}
