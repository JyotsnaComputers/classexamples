package gen;

public class Genric<E> {
	E obj; 
	public Genric(E obj) {
		this.obj = obj;
	}
	// Return ob.
	public E getob() {
		return obj;
	}

	public void showType() {
		System.out.println("Type of T is " +
				obj.getClass().getName());
	}
}