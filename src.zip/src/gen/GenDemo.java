package gen;

import oops.Student;

public class GenDemo {
	public static void main(String args[]) {

		Genric<Integer> iOb = new Genric<>(88);

		iOb.showType();

		Genric<String> sOb = new Genric<>("Mass");
		sOb.showType();

		Genric<Student> stuOb = new Genric<>(new Student(1, null));
		stuOb.showType();
//		int v = iOb.getob();
//		System.out.println("value: " + v);
//		System.out.println();

//		Genric<String> strOb = new Genric<String> ("Generics Test");
//		
//		strOb.showType();
//		
//		String str = strOb.getob();
//		System.out.println("value: " + str);
	}
}