package gen;
public class BoundsDemo {
	public static void main(String args[]) {
		Integer inums[] = { 1, 2, 3, 4, 5 };
		Bounds<Integer> iob = new Bounds<Integer>(inums);
		double v = iob.average();
		System.out.println("iob average is " + v);
		Double dnums[] = { 1.1, 2.2, 3.3, 4.4, 5.5 };
		Bounds<Double> dob = new Bounds<Double>(dnums);
		double w = dob.average();
		System.out.println("dob average is " + w);
		// This won't compile because String is not a
		// subclass of Number.
		// String strs[] = { "1", "2", "3", "4", "5" };
		// Bounds<String> strob = new Bounds<String>(strs);
		// double x = strob.average();
		// System.out.println("strob average is " + v);
	}
}