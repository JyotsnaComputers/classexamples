package gen;

public class Bounds<T extends Number> {
	T[] nums; // array of Number or subclass
	Bounds(T[] nums) {
		this.nums = nums;
	}
	// Return type double in all cases.
	double average() {
		double sum = 0.0;
		for(int i=0; i < nums.length; i++)
			sum += nums[i].doubleValue();
		return sum / nums.length;
	}
}