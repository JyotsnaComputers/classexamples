package arr;

public class JavaArrayDemo {

	public static void main(String[] args) {
		int[] myArray = new int[5];
		
		System.out.println(myArray.length);
	}
}