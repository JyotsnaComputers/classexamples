package str;

public class StringBufferDemo {

	public static void main(String[] args) {
		StringBuffer strBuff1 = new StringBuffer();

		System.out.println(strBuff1.length());
		System.out.println(strBuff1.capacity());

		strBuff1.append("My Java ");

		System.out.println(strBuff1);
		System.out.println(strBuff1.length());
		System.out.println(strBuff1.capacity());
		strBuff1.append(" Sample Programs for Sgtring Buffer examples ");
		System.out.println(strBuff1);
		System.out.println(strBuff1.length());
		System.out.println(strBuff1.capacity());

		strBuff1.ensureCapacity(54);
		System.out.println(strBuff1);
		System.out.println(strBuff1.length());
		System.out.println(strBuff1.capacity());
//
//		strBuff1.append(" Mutual");
//		System.out.println(strBuff1);
//		System.out.println(strBuff1.length());
//		System.out.println(strBuff1.capacity());
//		
//		strBuff1.append(" Trading");// Nanak Ramguda, GacchiBowli, Hyderabad");
//		System.out.println(strBuff1);
//		System.out.println(strBuff1.length());
//		System.out.println(strBuff1.capacity());	
//
//		strBuff1.append(", Telangana");
//		System.out.println(strBuff1);
//		System.out.println(strBuff1.length());
//		System.out.println(strBuff1.capacity());	
//
//		strBuff1.insert(4, " - ");
//		System.out.println(strBuff1);
//		System.out.println(strBuff1.length());
//		System.out.println(strBuff1.capacity());
//		
//		strBuff1.replace(4, 7, "###");
//		System.out.println(strBuff1);
//		System.out.println(strBuff1.length());
//		System.out.println(strBuff1.capacity());
//		
//		strBuff1.setCharAt(3, 's');
//		System.out.println(strBuff1);
//		System.out.println(strBuff1.length());
//		System.out.println(strBuff1.capacity());
//		
//		strBuff1.reverse();
//		System.out.println(strBuff1);
//		System.out.println(strBuff1.length());
//		System.out.println(strBuff1.capacity());
//		
		strBuff1.trimToSize();
		System.out.println(strBuff1);
		System.out.println(strBuff1.length());
		System.out.println(strBuff1.capacity());
	}
}