package str;

import java.util.StringTokenizer;

public class StringTokenizerDemo {
	public static void main(String[] args) {
		String str = "Concentrix Technology Company, Hyderabad";

		String splitted[] = str.split("a");
		for (String temp : splitted) {
			System.out.println(temp);
		}
		System.out.println("######");
		StringTokenizer tokens = new StringTokenizer(str, "a");

		while (tokens.hasMoreTokens())
			System.out.println(tokens.nextToken());
		System.out.println("*********");

//		tokens = new StringTokenizer(str, "a");
//
//		while (tokens.hasMoreTokens())
//			System.out.println(tokens.nextToken());
//		System.out.println("&&&&&&&&&&&&&");
//		tokens = new StringTokenizer(str, "au");
//
//		while (tokens.hasMoreTokens())
//			System.out.println(tokens.nextToken());
//		System.out.println("*********");

		tokens = new StringTokenizer(str, "oa", true);

		while (tokens.hasMoreTokens())
			System.out.println(tokens.nextToken());
		System.out.println("*********");

	}
}