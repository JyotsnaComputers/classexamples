package str;

public class StringDemo {

	public static void main(String[] args) {
		String str1 = "Java";
		String str3 = " Program";
		String str4 = str1.concat(str3);

		System.out.println(str1);
		System.out.println(str3);
		System.out.println(str4);

	}

}
