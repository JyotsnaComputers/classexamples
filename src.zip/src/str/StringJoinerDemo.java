package str;

import java.util.StringJoiner;

public class StringJoinerDemo {

	public static void main(String[] args) {
		StringJoiner joiner1 = new StringJoiner("-", "{", "}");

		System.out.println(joiner1);

		System.out.println(joiner1.length());

		joiner1.add("C").add("T").add("H");
		System.out.println(joiner1);
		System.out.println(joiner1.length());

		joiner1.add("Hyderabad");
		System.out.println(joiner1);
		System.out.println(joiner1.length());
//
//		StringJoiner joiner2 = new StringJoiner("-", "{", "}");
//		joiner2.add("Software");
//
//		joiner2.add("Development");
//		System.out.println(joiner2);
//
		StringJoiner joiner3 = new StringJoiner("*", "[", "]");
		joiner3.add("Java");

		joiner3.add("Developers");
		System.out.println(joiner3);
		joiner3.add("FSD");
		String str = joiner3.toString();
		System.out.println(str);

		joiner1.merge(joiner3);
		System.out.println(joiner1);

		joiner1.add("join");
		System.out.println(joiner1);

//		joiner2.add("Mass");
//		System.out.println(joiner2);

	}
}