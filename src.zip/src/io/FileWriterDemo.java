package io;

import java.io.FileWriter;

public class FileWriterDemo {

	public static void main(String[] args) throws Exception {
		FileWriter writer = null;

		writer = new FileWriter("f:/test/writer.txt");

//		writer.write("Mass Mutual, Hyderabad\n");
		writer.write("हिन्दी বাংলা తెలుగు मराठी தமிழ் ગુજરાતી ಕನ್ನಡ മലയാളം ਪੰਜਾਬੀ");

		writer.close();
		System.out.println("Written Successfully ");

	}
}