package io;

import java.io.RandomAccessFile;

public class RandomAccessFileDemo {

	public static void main(String[] args) throws Exception {
		RandomAccessFile raf = null;

		raf = new RandomAccessFile("f:/test/raf.txt", "rw");

		raf.seek(raf.length());
		raf.write("Concentrix, Hyderabad, Telangana".getBytes());

		raf.seek(0);

		int readByte = 0;

		while ((readByte = raf.read()) != -1) {
			System.out.print((char) readByte);
		}

		raf.close();

	}
}