package io;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student implements Serializable {

	private transient String imark;

	private static String board;

	public static String getBoard() {
		return board;
	}

	public static void setBoard(String board) {
		Student.board = board;
	}

	private long rno;
	private String firstName;
	private String lastName;
	private double marksOfSubject1;
	private double marksOfSubject2;
	private double marksOfSubject3;
}
