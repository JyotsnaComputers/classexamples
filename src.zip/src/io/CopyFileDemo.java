package io;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class CopyFileDemo {

	public static void main(String[] args) throws Exception {
		FileOutputStream merge = null;

		FileInputStream read = null;

		merge = new FileOutputStream("f:/test/merge.txt");

		read = new FileInputStream("f:/test/first.txt");

		int readByte = 0;
		while ((readByte = read.read()) != -1) {
			merge.write(readByte);
		}
		read.close();

		read = new FileInputStream("f:/test/second.txt");
		while ((readByte = read.read()) != -1) {
			merge.write(readByte);
		}

		read.close();
		merge.close();

	}

}
