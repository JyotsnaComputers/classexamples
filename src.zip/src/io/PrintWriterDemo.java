package io;

import java.io.PrintWriter;

public class PrintWriterDemo {

	public static void main(String[] args) throws Exception{
		PrintWriter writer = null;
		
		writer = new PrintWriter(System.out);
		
		writer.println("Mass Mutual");
		writer.println("Mass Mutual");
		writer.println("Mass Mutual");
		writer.println("Mass Mutual");
		
		writer.close();
		

	}

}
