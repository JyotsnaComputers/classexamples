package io;

import java.io.BufferedReader;
import java.io.FileReader;

public class BufferedReaderDemo {

	public static void main(String[] args) throws Exception{
		BufferedReader buffReader = null;

		buffReader = new BufferedReader(new FileReader("f:/test/buffreader.txt"));

		int readChar = 0;
		int count = 0;
		while((readChar = buffReader.read()) != -1) {
			count++;
			if(count == 3500) {
				buffReader.mark(1000);
				System.out.println("*************");
			}
			if(count == 4325) {
				buffReader.reset();
				System.out.println("\n\n");
				buffReader.skip(5);
			}
			System.out.print((char)readChar);
		}
		buffReader.close();
	}
}