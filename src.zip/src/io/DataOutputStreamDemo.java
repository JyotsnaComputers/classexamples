package io;

import java.io.DataOutputStream;
import java.io.FileOutputStream;

public class DataOutputStreamDemo {

	public static void main(String[] args) throws Exception {
		DataOutputStream dos = null;

		dos = new DataOutputStream(new FileOutputStream("f:/test/data.txt"));

		dos.write('#');
		dos.writeBoolean(true);
		dos.writeByte(35);
		dos.writeShort(257);
		dos.writeInt(345678);
		dos.writeLong(987654321);
		dos.writeFloat(3.14f);
		dos.writeDouble(456.789);
		dos.writeChar('#');

		System.out.println("Written Successfully ");
		dos.close();
	}
}