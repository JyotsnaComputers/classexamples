package io;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class ObjectOutputStreamDemo {

	public static void main(String[] args) throws Exception {
		ObjectOutputStream oos = null;

		oos = new ObjectOutputStream(new FileOutputStream("f:/test/object.txt"));
		Student student = new Student("markA", 1, "Rama", "Krishna", 56, 67, 68);
		Student.setBoard("CBSC");
		oos.write((Student.getBoard() + "\n").getBytes());
		oos.writeObject(student);

		student = new Student("markB", 2, "Radhey", "Shyam", 63, 65, 58);
		oos.writeObject(student);

		student = new Student("markC", 3, "Mahesh", "Rana", 73, 45, 58);
		oos.writeObject(student);

		oos.close();

		System.out.println("Succesfully Written ");
	}
}