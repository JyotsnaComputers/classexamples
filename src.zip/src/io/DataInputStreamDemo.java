package io;

import java.io.DataInputStream;
import java.io.FileInputStream;

public class DataInputStreamDemo {

	public static void main(String[] args) throws Exception {
		DataInputStream dis = null;

		dis = new DataInputStream(new FileInputStream("f:/test/data.txt"));

		System.out.print((char) dis.read());
		System.out.println("Bool " + dis.readBoolean());
		System.out.println("Byte " + dis.readByte());
		System.out.println("Short " + dis.readShort());
		System.out.println("Int " + dis.readInt());
		System.out.println("Long " + dis.readLong());
		System.out.println("Float " + dis.readFloat());
		System.out.println("Double " + dis.readDouble());
		System.out.println("Char " + dis.readChar());

		dis.close();
	}
}