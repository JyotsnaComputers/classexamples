package io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamDemo {

	public static void main(String[] args) {
		FileOutputStream fos = null;

		String cname = "Concentrix Technologies";
//		byte barr[] = {65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85};

		try {
			fos = new FileOutputStream("f:/test/file.txt", true);

			fos.write('#');

			fos.write(cname.getBytes());
		} catch (FileNotFoundException fnex) {

		} catch (IOException e) {

			e.printStackTrace();
		}
//			fos.write(barr);
//			fos.write(barr,5,10);
		try {
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("File written successfully ");

	}
}