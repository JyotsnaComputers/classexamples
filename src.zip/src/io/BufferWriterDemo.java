package io;



import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class BufferWriterDemo {

	public static void main(String[] args) {
		BufferedWriter buffWriter = null;

		String cname = "Mass Mutual, Gacchibowli, Hyderabad-500032";
		try {
			buffWriter = new BufferedWriter(new  FileWriter("f:/test/buffreader.txt"));
			//			buffos.write('#');
			for(int i=0;i<500;i++)
				buffWriter.write((i+ "\t" + cname + "\n" ).toCharArray());
			buffWriter.close();
			System.out.println("File written successfully ");
		} catch (FileNotFoundException e) {

		}catch (IOException e) {

		}
	}
}