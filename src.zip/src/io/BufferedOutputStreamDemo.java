package io;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedOutputStreamDemo {

	public static void main(String[] args) {
		BufferedOutputStream buffos = null;

		String cname = "Concentrix Technologies, Gacchibowli, Hyderabad-500032";

		try {
			buffos = new BufferedOutputStream(new FileOutputStream("f:/test/buffos.txt"));
			buffos.write('#');
			buffos.write(cname.getBytes());
			for (int i = 1; i <= 500; i++)
				buffos.write((i + "\t" + cname + "\n").getBytes());
//			fos.write(barr);
//			fos.write(barr,5,10);
//			buffos.flush();
			buffos.close();
			System.out.println("File written successfully ");
		} catch (FileNotFoundException e) {

		} catch (IOException e) {

		}

	}
}