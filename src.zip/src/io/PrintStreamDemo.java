package io;

import java.io.FileNotFoundException;
import java.io.PrintStream;

public class PrintStreamDemo {

	public static void main(String[] args) {
		PrintStream pStream = null;

		try {
			pStream = new PrintStream("f:/test/print.txt");
		} catch (FileNotFoundException e) {

		}

		pStream.println("Concentrix ");
		pStream.print("Gacchi");
		pStream.print("bowli");

		System.out.println("written Successfully");
		pStream.close();

		int dataInt = 100;
		double dataDouble = 456.789;

		System.out.printf("Data Int : %d \nData Double %f ", dataInt, dataDouble);

		System.out.format("\nData Int : %5d", dataInt);
		System.out.format("\nData Int : %d", dataInt);
		System.out.format("\nData Int : %.2f", dataDouble);
		System.out.format("\nData Int : %f", dataDouble);
	}
}