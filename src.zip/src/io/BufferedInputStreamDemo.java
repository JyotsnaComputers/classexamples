package io;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

public class BufferedInputStreamDemo {

	public static void main(String[] args) throws Exception {
		BufferedInputStream buffis = null;

		buffis = new BufferedInputStream(new FileInputStream("f:/test/buffos.txt"));

		int readByte = 0;
		int count = 0;
		while ((readByte = buffis.read()) != -1) {
			count++;
			if (count == 500) {
				buffis.mark(400);
				System.out.println("\n\n*************\n");
			}
			if (count == 825) {
				buffis.reset();
				System.out.println("\n\n*************\n\n");
			}
			System.out.print((char) readByte);
		}
		buffis.close();
	}
}
