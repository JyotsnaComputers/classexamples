package io;

import java.io.FileReader;

public class FileReaderDemo {

	public static void main(String[] args) throws Exception{
		FileReader reader = null;
		
		reader = new FileReader("f:/test/writer.txt");
		
		int readChar = 0;
		
		while((readChar = reader.read()) != -1) {
			System.out.print((char)readChar);
		}
		reader.close();
	}

}
