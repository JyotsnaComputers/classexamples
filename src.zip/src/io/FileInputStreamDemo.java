package io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamDemo {

	public static void main(String[] args) {
		FileInputStream fis = null;

//		File file = new File("f:/test/file.txt");

		int readByte = 0;
		try {
			fis = new FileInputStream("f:/test/file.txt");

//			while ((readByte = fis.read()) != -1) {
//				System.out.print((char) readByte);
//			}

			int available = fis.available();

			byte readBytes[] = new byte[available];

			fis.read(readBytes);

			System.out.println(new String(readBytes));

		} catch (FileNotFoundException e) {
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			fis.close();
		} catch (IOException e) {

		}

	}

}
