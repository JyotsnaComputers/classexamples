package io;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		File file = new File("f:/test/MultiplicationTableDemoWithWhile.java");

		if (file.exists()) {
			System.out.println(file.getAbsolutePath() + " EXISTS ");
		}

		if (file.canWrite()) {
			System.out.println("Write ");
		} else {
			System.out.println("NOT Write ");
		}

		File nFile = new File("f:/test/Multiplication.txt");

		try {
			nFile.createNewFile();
		} catch (IOException e) {

		}

		File folder = new File("f:/tst/massmutual/folder");

		boolean folderCreated = folder.mkdirs();
		if (!folderCreated) {
			System.out.println("Unable to create Specified Folder " + folder.getAbsolutePath());
		}

	}
}