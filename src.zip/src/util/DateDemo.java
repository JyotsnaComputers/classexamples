package util;

import java.util.Date;

public class DateDemo {

	public static void main(String[] args) {
		Date today = new Date();

		System.out.println(today);

		Date present = new Date(System.currentTimeMillis());
		System.out.println(present);

		Date specificDate = new Date(2023 - 1900, 0, 8);
		System.out.println(specificDate);

	}
}