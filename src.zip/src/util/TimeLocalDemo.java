package util;

import java.time.LocalTime;

public class TimeLocalDemo {

	public static void main(String[] args) {
		LocalTime now = LocalTime.now();
		
		System.out.println(now);
		
		LocalTime speficTime12 = LocalTime.of(12, 0);
		System.out.println(speficTime12);
		
		LocalTime speficTime124012 = LocalTime.of(12, 40,12);
		System.out.println(speficTime124012);
		
		LocalTime speficTimenano = LocalTime.of(12, 40,12,123456);
		System.out.println(speficTimenano);

	}
}