package util;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class PeriodDemo {

	public static void main(String[] args) {
		LocalDate indepence = LocalDate.of(1947, Month.AUGUST, 15);
		
		LocalDate republic = LocalDate.of(1952, Month.JANUARY, 26);
		
		Period period = Period.between(indepence, republic);
		
		
		System.out.println(period.getYears() + " " +
					period.getMonths() + " " + period.getDays());

	}
}