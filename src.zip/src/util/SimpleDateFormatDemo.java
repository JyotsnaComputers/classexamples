package util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SimpleDateFormatDemo {

	public static void main(String[] args) {
//		String pattern = "yyyy-MM-dd";
//		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
//
//		String date = simpleDateFormat.format(new Date());
//		System.out.println(date);

		//Creating a SimpleDateFormat For a Specific Locale
		String pattern = "EEEEE dd MMMMM yyyy HH:mm:ss.SSSZ";
		SimpleDateFormat simpleDateFormat =
		        new SimpleDateFormat(pattern, new Locale("da", "DK"));

		String date = simpleDateFormat.format(new Date());
		System.out.println(date);
		
		/*
		  dd-MM-yy	03-11-22
dd-MM-yyyy	03-11-2022
MM-dd-yyyy	11-03-2022
yyyy-MM-dd	2022-11-03
yyyy-MM-dd HH:mm:ss	2022-11-03 23:59:59
yyyy-MM-dd HH:mm:ss.SSS	2022-11-03 23:59:59.999
yyyy-MM-dd HH:mm:ss.SSSZ	2022-11-03 23:59:59.999+0100
EEEEE MMMMM yyyy HH:mm:ss.SSSZ	Thursday November 2022 11:45:42.720+0100
		 */
		
	}
}