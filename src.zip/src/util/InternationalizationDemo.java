package util;
import java.util.Locale;  
import java.util.ResourceBundle;  
public class InternationalizationDemo {  
	public static void main(String[] args) {  

		ResourceBundle bundle = ResourceBundle.getBundle("applicationResources", new Locale("en", "US"));  
		System.out.println("Message in "+Locale.US +":"+bundle.getString("welcome.message"));  
		System.out.println("Hello "+Locale.US +":"+bundle.getString("hello"));
		System.out.println();
		
		bundle = ResourceBundle.getBundle("applicationResources",new Locale("en","GB"));  
		System.out.println("Message in "+Locale.getDefault()+":"+bundle.getString("welcome.message"));  
		System.out.println("Hello "+Locale.getDefault() +":"+bundle.getString("hello"));
		System.out.println();
	
		bundle = ResourceBundle.getBundle("applicationResources",new Locale("in","TG"));  
		System.out.println("Message in "+Locale.getDefault()+":"+bundle.getString("welcome.message"));  
//		System.out.println("Hello "+Locale.getDefault() +":"+bundle.getString("hello"));
		System.out.println();

	}  
}  