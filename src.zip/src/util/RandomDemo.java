package util;

import java.util.Random;

public class RandomDemo {

	public static void main(String[] args) {
		Random rand = new Random();

		System.out.println("Random Integer " + rand.nextInt());
		System.out.println("Random Integer 100 " + rand.nextInt(100));

		System.out.println("Random Double " + rand.nextDouble());

		System.out.println("Random Boolean  " + rand.nextBoolean());
	}

}
