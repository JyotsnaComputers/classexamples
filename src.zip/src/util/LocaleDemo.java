package util;

import java.util.Locale;

public class LocaleDemo {

	public static void main(String[] args) {
//		Locale[] locals =  Locale.getAvailableLocales();
//		
//		
//		for(Locale local : locals) {
//			System.out.println(local.getDisplayCountry() +"\t"+ local.getDisplayLanguage() +"\t"+ local.getDisplayLanguage());
//		}
//		System.out.println("Number of locals  " + locals.length);

		Locale myCountry = new Locale("tel", "ind");

		System.out.println(myCountry.getDisplayCountry());
		System.out.println(myCountry.getDisplayName());

	}

}
