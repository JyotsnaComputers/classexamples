package util;

import java.time.ZoneId;
import java.util.Iterator;
import java.util.Set;

public class ZonesDemo {

	public static void main(String[] args) {
		Set<String> zones = ZoneId.getAvailableZoneIds();

		Iterator<String> zitr = zones.iterator();
		
		while(zitr.hasNext()) {
			System.out.println(zitr.next());
		}
		
		System.out.println("Avaialble Zones count " + zones.size());
	}
}