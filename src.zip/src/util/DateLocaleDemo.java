package util;

import java.time.LocalDate;
import java.time.Month;

public class DateLocaleDemo {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		
		System.out.println(today);

		LocalDate current = LocalDate.of(2022, 11, 2);
		System.out.println(current);
		
		LocalDate today2 = LocalDate.of(2022, Month.NOVEMBER, 2);
		System.out.println(today2);
		
		
		LocalDate after10Days = today.minusDays(-10);
		System.out.println(after10Days);
		
		
		
	}
}