package util;

import java.time.ZonedDateTime;

public class ZonedDateTimeDemo {

	public static void main(String[] args) {
		ZonedDateTime now = ZonedDateTime.now();
		
		System.out.println(now);

	}
}