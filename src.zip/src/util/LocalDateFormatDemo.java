package util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class LocalDateFormatDemo {

	public static void main(String[] args) {
		LocalDate date = LocalDate.now();
		  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
		  String text = date.format(formatter);
		  LocalDate parsedDate = LocalDate.parse(text, formatter);
		  
		  
		  System.out.println(text);
		  
		  System.out.println(parsedDate);
	}
}