package util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class DateTimeLocalDemo {

	public static void main(String[] args) {
		LocalDateTime dateTime = LocalDateTime.now();
		
		System.out.println(dateTime);
		
		System.out.println(LocalDateTime.of(1952,Month.JANUARY,26,13,30));
		
		System.out.println(LocalDateTime.of(1952,Month.JANUARY,26,13,30,20));
		
		System.out.println(LocalDateTime.of(1952,Month.JANUARY,26,13,30,12,233456));

		System.out.println(LocalDateTime.of(1952,1,26,13,30));
		
		System.out.println(LocalDateTime.of(1952,1,26,13,30,20));
		
		System.out.println(LocalDateTime.of(1952,1,26,13,30,12,233456));

		System.out.println(LocalDateTime.of(LocalDate.now(), LocalTime.of(14,20)));
	}
}