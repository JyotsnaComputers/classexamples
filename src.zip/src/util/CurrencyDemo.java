package util;

import java.util.Currency;
import java.util.Locale;

public class CurrencyDemo {

	public static void main(String[] args) {
		Currency usa = Currency.getInstance(Locale.US);

		System.out.println(usa.getSymbol() + "\t" + usa.getCurrencyCode() + "\t" + usa.getDisplayName());

		Locale in = new Locale("hin", "in");
		Currency india = Currency.getInstance(in);

		System.out.println(india.getSymbol() + "\t" + india.getCurrencyCode() + "\t" + india.getDisplayName());

	}
}