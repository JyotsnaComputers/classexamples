package basics;

public class StaticVars {
	public StaticVars(int simpleData) {
		super();
		this.simpleData = simpleData;
	}
	private static int statdata=2;
	private int simpleData;
	
	public static int getSdata() {
		return statdata;
	}
	public static void setSdata(int statdata) {
		StaticVars.statdata = statdata;
	}
	public int calculate() {
		return statdata * simpleData;
	}
}