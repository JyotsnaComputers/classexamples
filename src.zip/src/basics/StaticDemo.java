package basics;

public class StaticDemo {

	public static void main(String[] args) {
//		StaticBlocks block = new StaticBlocks();
//		StaticBlocks block2 = new StaticBlocks();

		System.out.println(StaticBlocks.sdata);
//		StaticBlocks.smethod();

//		StaticVars obj1 = null;
//		
//		obj1 = new StaticVars(10);
//		
//		StaticVars obj2 = new StaticVars(20);
//		
//		System.out.println(obj1.calculate());
//		System.out.println(obj2.calculate());
//		
//		StaticVars.setSdata(5);
//		System.out.println(obj2.calculate());
//		
//		StaticMethods.method();
	}
}