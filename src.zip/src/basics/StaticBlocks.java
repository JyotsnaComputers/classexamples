package basics;

public class StaticBlocks {
	public static final int sdata;

	static {
		sdata = 200;
	}

	static void smethod() {
		System.out.println("Staic methid called ");
	}

	static {
		System.out.println("ONE My Static Block");
	}

	static {
		System.out.println("TWO My Static Block");
	}

	static {
		System.out.println("THIRD My Static Block");
	}
}