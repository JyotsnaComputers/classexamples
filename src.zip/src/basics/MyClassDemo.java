package basics;

class MyClass implements Cloneable {
	public MyClass clone() throws CloneNotSupportedException {
		return (MyClass) super.clone();
	}

	int data = 10;
}

public class MyClassDemo {

	static void myMethod(MyClass obj) {
		obj.data = 20;
	}

	public static void main(String[] args) throws Exception {
		MyClass obj = new MyClass();
		MyClass ref = obj.clone();

		System.out.println(obj.data);

		myMethod(ref);
		System.out.println(obj.data);
	}
}
