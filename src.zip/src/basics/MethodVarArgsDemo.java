package basics;

public class MethodVarArgsDemo {

	public static void main(String[] args) {
		varArgMethod(new int[] {1,2,3,4});
		varArgMethod(new int[] {1,2});
		varArgMethod(new int[] {1,2,3,4,6,6,7});
		
		System.out.println(addition(""));
		System.out.println(addition("",4, 5));
		System.out.println(addition("",5,7,9));
		System.out.println(addition("",7,4,9,5));
		
	}
	static void varArgMethod(int array[]) {
		for(int index=0; index < array.length; index++) {
			System.out.print(array[index] + "\t");
		}
		System.out.println();
	}
	
//	static long addition(int ... array) {
//		long result = 0;
//		for(int index=0; index < array.length; index++) {
//			result += array[index];
//		}
//		return result;
//	}
	static long addition(String name, int ... array) {
		long result = 0;
		for(int index=0; index < array.length; index++) {
			result += array[index];
		}
		return result;
	}

}