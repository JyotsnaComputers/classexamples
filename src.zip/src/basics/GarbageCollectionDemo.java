package basics;

public class GarbageCollectionDemo {

	public static void main(String[] args) {
		MaritiCar2010 ref = null;

		for (int i = 0; i < 5; i++) {
			System.out.println(i);
			ref = new MaritiCar2010();
		}

		System.gc();
		System.out.println("End of Main ");
	}
}