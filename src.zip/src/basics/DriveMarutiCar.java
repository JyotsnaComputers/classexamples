package basics;

public class DriveMarutiCar {

	public static void main(String[] args) {
		MarutiCar2005 car10 = new MaritiCar2010();

		car10.takeTurn();

	}

}
