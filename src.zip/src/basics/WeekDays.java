package basics;

public enum WeekDays {
	SUNDAY(20,"First Day"), MONDAY(20,"Second Day"), TUESDAY(30,""), WEDDAY(30,""), THURDAY(40,""), FRIDAY(40,""), SATDAY(50,"Last Day");
	
	private int val;
	private String desc;
	WeekDays(int val, String desc){
		this.val = val;
		this.desc = desc;
	}
	public int getVal() {
		return val;
	}
	public String getDesc() {
		return desc;
	}
	
	public static void main(String[] args) {
		System.out.println("Hello Enum");
	}
}