package basics;

public class ForEachDemo {

	public static void main(String[] args) {
		int array[] = new int[] {23,45,63,44,26,78,57,92,36};

		//		for(int index=0; index < array.length; index++) {
		//			System.out.print(array[index]++ + "\t");
		//		}
		//		System.out.println();
		//		for(int index=0; index < array.length; index++) {
		//			System.out.print(array[index] + "\t");
		//		}
		//		System.out.println();

		for(int temp : array) {
			System.out.print(temp++ + "\t");
		}
		System.out.println();
		for(int index=0; index < array.length; index++) {
			System.out.print(array[index] + "\t");
		}
		System.out.println();
		for(int temp : array) {
			System.out.print(temp + "\t");
		}
		System.out.println();
	}
}