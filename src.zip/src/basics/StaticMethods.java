package basics;

public class StaticMethods {
	private static int statdata=2;
	
	private int simpleData;
	
	public static void method() {
		System.out.println("Static Method " + statdata);
	}
	
	public void simpleMethod() {
		method();
	}
}