package basics;

public class MaritiCar2010 extends MarutiCar2005 {

	public void takeTurn() {
		System.out.println("Turing Using two fingures");
	}

	@Override
	public void finalize() {
//		System.out.println("GC called ");
	}
}
