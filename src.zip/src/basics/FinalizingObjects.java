package basics;

class MyDemoClass{
	private static int data=0;
	private int objData;
	public MyDemoClass(){
		objData =  data++;
	}
	public void finalize() {
		System.out.println("Object Garbage Collected " + objData);
	}
}
public class FinalizingObjects {

	public static void main(String[] args) {
		while(true) {
			new MyDemoClass();
		}
	}
}