package basics;

public class GlobalConstantsDemo {

	public static void main(String[] args) {
		WeekDays today = WeekDays.FRIDAY;
		System.out.println(today);
		
		System.out.println(today.ordinal());
		
		System.out.println(today.name());
		
		WeekDays day = today;
		
		String strDay = today.toString();
		
		WeekDays[] days =  WeekDays.values();
		
		for(WeekDays temp : days) {
			System.out.println(temp.ordinal() + "\t" + temp + "\t" + temp.getVal() + "\t" + temp.getDesc() );
		}
	}
}