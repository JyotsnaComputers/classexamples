package basics;

public class MarutiCar2005 {
	void takeTurn() {
		System.out.println("Turing Using both hands");
	}
}
