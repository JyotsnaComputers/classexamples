package wrapper;

public class WrapperDemo {

	public static void main(String[] args) {
		int ivar = 10; // 
		
		Integer iObj1 = 10; // Auto Boxing Wrapped
		Integer iObj2 = 20;
		//Auto Unboxing 
		//Auto Boxing
		Integer resultObj =  iObj1 + iObj2;
	}
}