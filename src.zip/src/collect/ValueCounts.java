package collect;

import java.util.HashMap;
import java.util.Scanner;

public class ValueCounts {

	public static void main(String[] args) {
		System.out.println("Enter a String value ");
		Scanner scanner = new Scanner(System.in);
		
		String inputStr = scanner.next();
		scanner.close();
		char inputArray[] = inputStr.toCharArray();
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		
		for(int index=0; index< inputArray.length; index++) {
			if(map.isEmpty()) {
				map.put(inputArray[index], 1);
			}
			else
			if(map.containsKey(inputArray[index])) {
				int count = map.get(inputArray[index]);
				map.put(inputArray[index], ++count);
			}
			else {
				map.put(inputArray[index], 1);
			}
		}
		
		System.out.println(map);

	}
}