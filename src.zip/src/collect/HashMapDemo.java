package collect;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HashMapDemo {
	public static void main(String[] args) {
		HashMap<Integer, String> hashMap = new HashMap<Integer, String>();
		
		hashMap.put(1, "Mounika");
		hashMap.put(2, "Tirumala");
		hashMap.put(3, "Nikhitha");
		hashMap.put(4, "Divya");
		
//		System.out.println(hashMap);
		
		Set<Integer> keys = hashMap.keySet();
		Iterator<Integer> itr = keys.iterator();
		
		while(itr.hasNext()) {
			int key = itr.next();
			System.out.println(key + "\t" + hashMap.get(key));
		}
	}
}