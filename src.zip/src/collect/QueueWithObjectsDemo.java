package collect;

import java.util.LinkedList;
import java.util.Queue;

public class QueueWithObjectsDemo {

	public static void main(String[] args) {
		Queue<Employee> olist = new LinkedList<Employee>();

		olist.add(new Employee());
		olist.add(new Employee(1, "Rama", "Krishna", 34000));
		olist.add(new Employee(2, "Kiran", "Kumar", 32000));
		olist.add(null);
		olist.add(new Employee(3, "Mahesh", "Chandra", 35000));
		olist.add(new Employee(4, "Mukesh", "Rout", 33000));
		olist.add(new Employee(5, "Shiva", "Shankar", 34000));
		olist.offer(new Employee(10, "Sachin", "Rana", 35000));

		while (olist.size() > 0) {
			System.out.println(olist.poll());
		}
	}

}