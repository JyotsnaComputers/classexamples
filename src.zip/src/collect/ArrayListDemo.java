package collect;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		ArrayList vlist = new ArrayList();
		System.out.println(vlist.size());
		vlist.add(10);
		vlist.add(20);
		vlist.add("Mass");
		vlist.add(5.67);
		
		System.out.println(vlist);
		
		vlist.add(2,"TWO");
		vlist.add(99);
		vlist.add(88);
		vlist.add(77);
		vlist.add(22);
		vlist.add(11);
		vlist.add(22);
		vlist.add(33);
		System.out.println(vlist);
		System.out.println(vlist.size());
//		System.out.println(vlist.capacity());
	}
}