package collect;

import java.util.Objects;

public class Employee implements Comparable<Employee> {

	private long empno;
	private String firstName;
	private String lastName;
	private double basicSal;

	public Employee() {
		super();
	}

	public Employee(long empno, String firstName, String lastName, double basicSal) {
		super();
		this.empno = empno;
		this.firstName = firstName;
		this.lastName = lastName;
		this.basicSal = basicSal;
	}

	public long getEmpno() {
		return empno;
	}

	public void setEmpno(long empno) {
		this.empno = empno;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getBasicSal() {
		return basicSal;
	}

	public void setBasicSal(double basicSal) {
		this.basicSal = basicSal;
	}

	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", firstName=" + firstName + ", lastName=" + lastName + ", basicSal="
				+ basicSal + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(basicSal, empno, firstName, lastName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
//		Employee other = (Employee) obj;
//		return Double.doubleToLongBits(basicSal) == Double.doubleToLongBits(other.basicSal) && empno == other.empno
//				&& Objects.equals(firstName, other.firstName) && Objects.equals(lastName, other.lastName);
		return this.empno == ((Employee) obj).empno;
	}

	@Override
	public int compareTo(Employee obj) {

		return this.lastName.compareTo(obj.lastName);
	}
}