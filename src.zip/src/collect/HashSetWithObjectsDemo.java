package collect;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetWithObjectsDemo {

	public static void main(String[] args) {
		HashSet<Employee> objectHashSet = new HashSet<Employee>();
		objectHashSet.add(new Employee(10, "Sachin", "Rana", 35000));
		objectHashSet.add(new Employee());
		objectHashSet.add(new Employee(1, "Rama", "Krishna", 34000));
		objectHashSet.add(new Employee(2, "Kiran", "Kumar", 32000));
		objectHashSet.add(null);
		objectHashSet.add(new Employee(10, "Sachin", "Rana", 35000));
		objectHashSet.add(new Employee(2, "Mahesh", "Chandra", 35000));
		objectHashSet.add(new Employee(2, "Mukesh", "Rout", 33000));
		objectHashSet.add(new Employee(2, "Shiva", "Shankar", 34000));
		objectHashSet.add(new Employee(10, "Sachin", "Rana", 35000));
		Iterator<Employee> itr = objectHashSet.iterator();

		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
