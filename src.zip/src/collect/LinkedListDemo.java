package collect;

import java.util.ArrayList;
import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		LinkedList llist = new LinkedList();
		
		System.out.println(llist.size());
		llist.add(10);
		llist.add(20);
		llist.add("Mass");
		llist.add(5.67);
		
		System.out.println(llist);
		
		llist.add(2,"TWO");
		llist.add(99);
		llist.add(88);
		llist.add(77);
		llist.add(22);
		llist.add(11);
		llist.add(22);
		llist.add(33);
		System.out.println(llist);
		System.out.println(llist.size());
//		System.out.println(vlist.capacity());

	}

}
