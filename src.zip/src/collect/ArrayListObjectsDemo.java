package collect;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListObjectsDemo {

	public static void main(String[] args) {
		ArrayList<Employee> olist = new ArrayList<Employee>();

		olist.add(new Employee());
		olist.add(new Employee(1, "Rama", "Krishna", 34000));
		olist.add(new Employee(2, "Kiran", "Kumar", 32000));
		olist.add(null);
		olist.add(new Employee(3, "Mahesh", "Chandra", 35000));
		olist.add(new Employee(4, "Mukesh", "Rout", 33000));
		olist.add(new Employee(5, "Shiva", "Shankar", 34000));
		olist.add(4, new Employee(10, "Sachin", "Rana", 35000));
		Iterator<Employee>  itr = olist.iterator();

		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("************");
		for(int index=0; index < olist.size(); index++) {
			System.out.println(olist.get(index));
		}
	}
}