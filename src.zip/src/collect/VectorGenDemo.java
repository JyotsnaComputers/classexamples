package collect;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class VectorGenDemo {

	public static void main(String[] args) {
		Vector<Integer> vlist = new Vector<Integer>();
		
		vlist.add(29);
		vlist.add(12);
		vlist.add(39);
		vlist.add(42);
		vlist.add(25);
		vlist.add(62);
		vlist.add(35);
		vlist.add(12);
		vlist.add(29);
		vlist.add(33);
		vlist.add(0, 100);
		vlist.add(9, null);
		vlist.add(9, null);
		vlist.add(9, null);
		
		System.out.println(vlist);

		Iterator<Integer> itr = vlist.iterator();
		
		while(itr.hasNext()) {
			System.out.print(itr.next() + "\t");
		}
		System.out.println();
		
		ListIterator<Integer> litr = vlist.listIterator();
		
		while(litr.hasNext()) {
			System.out.print(litr.next() + "\t");
		}
		System.out.println();
	}
}