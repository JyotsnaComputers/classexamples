package collect;

import java.util.Properties;

public class MyPropertiesDemo {

	public static void main(String[] args) {
		Properties myProps = new Properties();
		
		myProps.setProperty("OS", "Win 11");
		myProps.setProperty("Country", "India");
		myProps.setProperty("Currency", "Rupee");
		
		System.out.println(myProps);
	}
}
