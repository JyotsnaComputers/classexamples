package collect;

import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class PropertiesDemo {

	public static void main(String[] args) {
		Properties props = System.getProperties();

		Set keys = props.keySet();
		Iterator itr = keys.iterator();
		while (itr.hasNext()) {
			String key = (String) itr.next();
			System.out.println(key + "\t:\t" + props.get(key));
		}

//		System.out.println("\n\n****************\n\n");
//		Enumeration eitr = props.propertyNames();
//		
//		while(eitr.hasMoreElements()) {
//			String prop = (String)eitr.nextElement();
//			
//			System.out.println(prop + "\t:\t" + props.getProperty(prop));
//		}
	}
}