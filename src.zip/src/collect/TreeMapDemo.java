package collect;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapDemo {

	public static void main(String[] args) {
		TreeMap<Integer, String> treeMap = new TreeMap<Integer, String>();
		treeMap.put(3, "Nikhitha");
		treeMap.put(4, "Divya");
		treeMap.put(1, "Mounika");
		treeMap.put(2, "Tirumala");
		
		Set<Integer> keys = treeMap.keySet();
		Iterator<Integer> itr = keys.iterator();
		
		while(itr.hasNext()) {
			int key = itr.next();
			System.out.println(key + "\t" + treeMap.get(key));
		}

	}

}
