package collect;

import java.util.Iterator;
import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		Stack<Employee> olist = new Stack<Employee>();

		olist.push(new Employee());
		olist.add(new Employee(1, "Rama", "Krishna", 34000));
		olist.add(new Employee(2, "Kiran", "Kumar", 32000));
		olist.push(null);
		olist.push(new Employee(3, "Mahesh", "Chandra", 35000));
		olist.push(new Employee(4, "Mukesh", "Rout", 33000));
		olist.add(new Employee(5, "Shiva", "Shankar", 34000));
		olist.add(4, new Employee(10, "Sachin", "Rana", 35000));
		Iterator<Employee> itr = olist.iterator();

		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

		System.out.println("*************");
		while (olist.size() > 0) {
			System.out.println(olist.pop());
		}
	}
}