package collect;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashtableDemo {

	public static void main(String[] args) {
		Hashtable<String, Integer> numbers = new Hashtable<String, Integer>();
		numbers.put("one", 1);
		numbers.put("two", 2);
		numbers.put("three", 3);
		numbers.put("four", 4);
		numbers.put("null", 2);
		numbers.put("FF", 44);
		numbers.put("FF2", 44);
		//System.out.println(numbers);
		
		System.out.println(numbers.get("FA"));
		
		Set<String> keys = numbers.keySet();
		
		Iterator<String> keysItr = keys.iterator();
		while(keysItr.hasNext()) {
			String key = keysItr.next();
			
			System.out.println(key + "\t" + numbers.get(key));			
		}
		System.out.println("****************");
		Set<Map.Entry<String, Integer>> entry = numbers.entrySet();
		
		Iterator<Map.Entry<String, Integer>> eitr = entry.iterator();
		
		while(eitr.hasNext()) {
			Map.Entry<String, Integer> mapEntry = eitr.next();
			System.out.println(mapEntry.getKey() + "\t" + mapEntry.getValue());
		}
	}
}