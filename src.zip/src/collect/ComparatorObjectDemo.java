package collect;

import java.util.Comparator;

class MyClass implements Comparator<String>{

	private int id;
	public MyClass() {
		// TODO Auto-generated constructor stub
	}
	public MyClass(int id) {
		this.id = id;
	}
	@Override
	public int compare(String obj1, String obj2) {
		// TODO Auto-generated method stub
		return obj1.compareTo(obj2);
	}
}

public class ComparatorObjectDemo {

	public static void main(String[] args) {
//		MyClass obj1 = new MyClass(10);
//		MyClass obj2 = new MyClass(9);
		
		MyClass dummy = new MyClass();
		
		int comparedValue = dummy.compare("mass", "Mass");
		System.out.println(comparedValue);
	}
}