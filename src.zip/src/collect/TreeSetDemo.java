package collect;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		TreeSet<Employee> sortedSet = new TreeSet<Employee>();

		sortedSet.add(new Employee(10, "Sachin", "Rana", 35000));
		//		sortedSet.add(new Employee());
		sortedSet.add(new Employee(1, "Rama", "Krishna", 34000));
		sortedSet.add(new Employee(2, "Kiran", "Kumar", 32000));
		//		sortedSet.add(null);
		sortedSet.add(new Employee(10, "Sachin", "Rana", 35000));
		sortedSet.add(new Employee(3, "Mahesh", "Chandra", 35000));
		sortedSet.add(new Employee(4, "Mukesh", "Rout", 33000));
		sortedSet.add(new Employee(5, "Shiva", "Shankar", 34000));
		sortedSet.add(new Employee(10, "Sachin", "Rana", 35000));
		Iterator<Employee>  itr = sortedSet.iterator();

		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

		System.out.println("************");
		itr = sortedSet.descendingIterator();

		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("#########");

		SortedSet<Employee> subSet =  sortedSet.subSet(new Employee(3, "Mahesh", "Chandra", 35000), new Employee(10, "Sachin", "Rana", 35000));

		itr = subSet.iterator();

		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}