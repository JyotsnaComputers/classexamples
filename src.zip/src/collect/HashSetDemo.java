package collect;

import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {
		HashSet myset = new HashSet();
		
		System.out.println(myset.size());
		myset.add(22);
		myset.add(10);
		myset.add(20);
		myset.add("Mass");
		myset.add(5.67);
		myset.add(22);
		System.out.println(myset);
		
		myset.add(99);
		myset.add(88);
		myset.add(77);
		myset.add(22);
		myset.add(11);
		myset.add(22);
		myset.add(33);
		System.out.println(myset);
		System.out.println(myset.size());

	}
}