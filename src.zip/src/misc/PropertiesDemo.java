package misc;

import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class PropertiesDemo {

	public static void main(String[] args) {
		Properties prop = System.getProperties();

		Set keys = prop.keySet();

		Iterator itr = keys.iterator();

		while (itr.hasNext()) {
			String key = itr.next().toString();

			System.out.println(key + "\t" + prop.getProperty(key));
		}
	}

}
