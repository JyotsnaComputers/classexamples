package misc;

import java.io.IOException;

public class RuntimeDemo {

	public static void main(String[] args) throws IOException {
		Runtime run = Runtime.getRuntime();
		System.out.println("Free Momory " + run.freeMemory());
		System.out.println("No of Proc " + run.availableProcessors());
		run.exec("mspaint");
	}
}