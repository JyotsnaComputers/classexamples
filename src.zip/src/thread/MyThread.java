package thread;

public class MyThread extends Thread{
	
	public MyThread(String name) {
		super(name);
	}
	public MyThread() {
		super();
	}
	public void run() {
		loop();
	}
	
	private void loop() {
		for(int index = 0; index < 10; index++) {
			System.out.println(index +"-Daemon :" + isDaemon()+"-Id:"+getId() + "-Priority:" +getPriority() + " -" + getName() + "\t");
		}
		System.out.println();
	}
}