package thread;

public class FileProgram {
	public static void main(String[] args) {
		new CopyDataThread("f:/test/Box.java", "f:/test/BoxC.txt");
	}
}