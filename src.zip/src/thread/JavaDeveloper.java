package thread;

public class JavaDeveloper extends Employee implements Runnable{
	private String skillSet = "Java FS";
	
	@Override
	public void run() {
		showSkillSet();
	}
	
	void showSkillSet() {
		System.out.println(skillSet);
	}
}