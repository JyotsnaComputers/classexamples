package thread.comm3;
public class ThreadInterCommunicationMain {

	public static void main(String args[])
	{
		// Book object on which wait and notify method will be called
		Book book=new Book("Java Complete");
		BookReader nikithaReader=new BookReader(book);
		BookReader murliReader=new BookReader(book);

		// BookReader threads which will wait for completion of book
		Thread johnThread=new Thread(nikithaReader,"John");
		Thread arpitThread=new Thread(murliReader,"Arpit");

		arpitThread.start();
		johnThread.start();

		// To ensure both readers started waiting for the book
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		// BookWriter thread which will notify once book get completed
		BookWriter bookWriter=new BookWriter(book);
		Thread bookWriterThread=new Thread(bookWriter);
		bookWriterThread.start();

	}

}