package thread;

public class ThreadPrioritiesDemo {

	public static void main(String[] args) {
		SimpleThread t1 = new SimpleThread();

		SimpleThread t2 = new SimpleThread();

		SimpleThread t3 = new SimpleThread();

		t1.setPriority(Thread.MAX_PRIORITY);
		t2.setPriority(Thread.MIN_PRIORITY);
		t1.start();
		t2.start();
		t3.start();

		System.out.println("Before Join in Main");
		try {
			t1.join();
			t2.join();
			t3.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("End of Main");
	}
}