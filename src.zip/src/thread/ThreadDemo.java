package thread;

class SimpleThread extends Thread {
	public SimpleThread() {

	}

	public SimpleThread(String tname) {
		super(tname);
	}

	public void run() {
		for (int i = 1; i <= 10; i++)
			System.out.println(getName() + "\tProirity " + getPriority() + "\t" + i);
	}
}

public class ThreadDemo {

	public static void main(String[] args) {
		Thread t1 = new SimpleThread();
//		t1.run();
		t1.start();

		t1 = new SimpleThread("T2");
		t1.start();
		for (int i = 1; i <= 10; i++)
			System.out.println(Thread.currentThread().getId() + "\t" + i);

	}

}
