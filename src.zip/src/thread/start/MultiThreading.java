package thread.start;
public class MultiThreading extends Thread
{
    public void run ()
    {
        for (int i = 0; i < 50; i++)
        {
            System.out.println (getName () + "RUN:" + i);
        }
    }
    public static void main (String[]args)
    {
        MultiThreading mt1 = new MultiThreading ();
        mt1.start ();
        MultiThreading mt2 = new MultiThreading ();
        mt2.start ();
        MultiThreading mt3 = new MultiThreading ();
        mt3.start ();
    }
}