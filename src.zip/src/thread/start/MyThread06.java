package thread.start;
class AddThread extends Thread
{
    int sum = 0;
    public void run ()
    {
        for (int i = 0; i <= 50; i++)
        {
            sum += i;
            System.out.println ("the summation :" + sum);
        }
    }
}
class SubThread extends Thread
{
    int diff = 0;
    public void run ()
    {
        for (int i = 50; i >= 50; i--)
        {
            diff -= i;
            System.out.println ("the substraction is :" + diff);
        }
    }
}
public class MyThread06
{
    public static void main (String args[])
    {
        AddThread add = new AddThread ();
        add.start ();
        SubThread sub = new SubThread ();
        sub.start ();
        System.out.println ("main exited");
    }
}