package thread.start;
public class MyThread04 extends Thread
{
    public void run ()
    {
        for (int i = 0; i <= 50; i++)
        {
            System.out.println ("Run: " + i);
        }
    }
    public static void main (String[]args)
    {
        MyThread04 mt = new MyThread04();
        mt.start ();
//        mt.start ();
        for (int i = 0; i <= 50; i++)
        {
            System.out.println ("Main: " + i);
        }
    }
}