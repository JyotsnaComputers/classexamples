package thread.start;
public class MyThread08 extends Thread
{
     public void run ()
     {
         System.out.println ("custom");
     }
     public void start ()
     {
         System.out.println ("start");
//         run();
         super.start ();
     }
     public static void main (String args[])
     {
         MyThread08 mt = new MyThread08 ();
         mt.start();
         System.out.println ("main");
     }
}