package thread.start;
public class MyThread03 extends Thread
{
    public void run ()
    {
        for (int i = 0; i <= 5; i++)
        {
            System.out.println ("Run: " + i);
        }
    }
    public static void main (String[]args)
    {
        MyThread03 mt = new MyThread03();
        mt.start ();
        mt.run ();
        for (int i = 0; i <= 5; i++)
        {
            System.out.println ("Main: " + i);
        }
    }
}