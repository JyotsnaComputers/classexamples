package thread.start;
public class MyThread02 extends Thread
{
    public void run ()
    {
        for (int i = 0; i <= 5; i++)
        {
            System.out.println ("Run: " + i);
        }
    }
    public static void main (String[]args)
    {
        MyThread02 mt = new MyThread02();
        mt.run();
        mt.start();
        for (int i = 0; i <= 5; i++)
        {
            System.out.println ("Main: " + i);
        }
    }
}