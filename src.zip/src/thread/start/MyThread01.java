package thread.start;
public class MyThread01 extends Thread
{
    public void run ()
    {
        for (int i = 0; i <= 5; i++)
        {
            System.out.println ("Run: " + i);
        }
    }
    public static void main (String[]args)
    {
        MyThread01 mt = new MyThread01 ();
        mt.run ();
        for (int i = 0; i <= 5; i++)
        {
            System.out.println ("Main: " + i);
        }
    }
}