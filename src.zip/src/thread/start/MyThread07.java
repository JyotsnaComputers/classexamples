package thread.start;
public class MyThread07 extends Thread
{
    public void run ()
    {
        System.out.println ("run");
    }
    public void start ()
    {
        System.out.println ("start");
    }
    public static void main (String args[])
    {
        Thread mt = new MyThread07 ();
        mt.start ();
        System.out.println ("main");
    }
}