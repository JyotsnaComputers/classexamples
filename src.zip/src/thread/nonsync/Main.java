package thread.nonsync;

public class Main {
	public static void main(String args[]) {
		Callme target = new Callme();
		new Caller(target, "Hello");
		new Caller(target, "Synchronized");
		new Caller(target, "World");
	}
}