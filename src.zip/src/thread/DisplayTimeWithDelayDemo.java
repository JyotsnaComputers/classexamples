package thread;

public class DisplayTimeWithDelayDemo {

	public static void main(String[] args) {
		new DisplayTimeWithDelay();

	}
}