package thread.noncomm;

public class Product {
	int n;
	int get() {
		System.out.println("Got: " + n);
		return n;
	}
	void put(int n) {
		this.n = n;
		System.out.println("Put: " + n);
	}
}