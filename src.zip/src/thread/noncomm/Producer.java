package thread.noncomm;

public class Producer implements Runnable {
	Product product;
	Producer(Product product) {
		this.product = product;
		new Thread(this, "Producer").start();
	}
	public void run() {
		int i = 0;
		while(true) {
			product.put(i++);
		}
	}
}