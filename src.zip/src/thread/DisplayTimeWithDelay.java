package thread;

import java.time.LocalTime;

public class DisplayTimeWithDelay implements Runnable{

	public DisplayTimeWithDelay(){
		new Thread(this).start();
	}
	@Override
	public void run() {
		boolean bool = true;
		try {
			while(bool) {
				LocalTime currentTime  = LocalTime.now();
				System.out.println(currentTime);
				Thread.sleep(5000);
			}
		}catch(InterruptedException iex) {
			System.out.println("Thread Interrupted ");
		}
		System.out.println("End of run");
	}

}
