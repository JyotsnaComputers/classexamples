package thread;

public class JavaDeveloperAsThread {

	public static void main(String[] args) {
		Runnable jdev = new JavaDeveloper();
		
		Thread thread = new Thread(jdev);
		
		thread.start();
		
	}
}