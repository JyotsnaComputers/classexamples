package thread;

public class ProgramFlow {

	public static void main(String[] args) {
		System.out.println("Hi, Mass Mutual");
		
		MyThread thread = new MyThread();
		
		thread.start();
		for(int index = 0; index < 10; index++) {
			System.out.print(index + "\t");
		}
		System.out.println();

		

	}
}