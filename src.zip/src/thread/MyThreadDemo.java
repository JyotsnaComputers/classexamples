package thread;

public class MyThreadDemo {

	public static void main(String[] args) {
		MyThread threadOne = new MyThread();
		
		MyThread threadTwo = new MyThread();

		MyThread threadThree = new MyThread();
		
		MyThread threadFour = new MyThread();
		
		threadThree.setDaemon(true);		

		threadOne.start();		
//		threadOne.setPriority(Thread.MAX_PRIORITY);
		threadTwo.start();
		threadThree.start();

		
		try {
			threadOne.join();
		} catch (InterruptedException e) {
			
		}
//		threadFour.start();
		
		Thread current = Thread.currentThread();
//		current.setDaemon(true); // NOT POSSIBLE for main
		for(int index = 0; index < 10; index++) {
			System.out.print(index +"Id"+current.getId() + "-Priority " + current.getPriority() + "-" + current.getName() + "\t");
		}
		System.out.println();
	}

}
