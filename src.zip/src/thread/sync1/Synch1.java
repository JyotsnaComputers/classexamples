package thread.sync1;

public class Synch1 {
	public static void main(String args[]) {
		Callme target = new Callme();
		new Caller(target, "Hello");
		new Caller(target, "Synchronized");
		new Caller(target, "World");
		
	}
}