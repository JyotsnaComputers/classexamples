package assign;

public class BlankNameException extends Exception {
	public BlankNameException(String message) {
		super(message);
	}
}