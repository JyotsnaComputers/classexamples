package assign;

public class EmployeeNameValidity {
	public static void main(String[] args) {
		Employee empObj = new Employee("Rama", "");
		
		boolean valid = false;
		try {
		valid = validName(empObj);
		}catch (BlankNameException bex) {
			System.out.println(bex.getMessage());
		}
	}
	
	static boolean validName(Employee emp) throws BlankNameException{
		boolean rtnValue = false;
		if(emp.getFirstName().isEmpty() && emp.getLastName().isEmpty())
			throw new BlankNameException("Name cannot be empty ");
		else
			rtnValue = true;
		return rtnValue;
	}
}
