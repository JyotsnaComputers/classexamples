package assign;

import java.util.Scanner;

public class TrafficLightsString {

	public static void main(String[] args) {
		String option = null;
		
		System.out.println("RED");
		System.out.println("YELLOW");
		System.out.println("GREEN");
		System.out.println("Select light ");
		Scanner scanner = new Scanner(System.in);
		option = scanner.next();
		
		switch(option) {
		case "RED":
			System.out.println("STOP on RED");
			break;
		case "YELLOW":
			System.out.println("READY on YELLOW");
			break;
		case "GREEN":
			System.out.println("GO on GREEN");
			break;
		default:
			System.out.println("Invalid option ");
		}
		scanner.close();
	}
}