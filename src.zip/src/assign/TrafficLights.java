package assign;

import java.util.Scanner;

public class TrafficLights {

	public static void main(String[] args) {
		/*
		 Write a java program that simulates a traffic light. 
		 The program lets the user select one of three lights: 
		 red, yellow, or green with radio buttons. 
		 On entering the choice, an appropriate message with 
		 �stop� or �ready� or �go� should appear in the console .
		 Initially there is no message shown.
		 */

		int option = 0;
		
		System.out.println("1. RED");
		System.out.println("2. YELLOW");
		System.out.println("3. GREEN");
		System.out.println("Select light ");
		Scanner scanner = new Scanner(System.in);
		option = scanner.nextInt();
		
		switch(option) {
		case 1:
			System.out.println("STOP on RED");
			break;
		case 2:
			System.out.println("READY on YELLOW");
			break;
		case 3:
			System.out.println("GO on GREEN");
			break;
		default:
			System.out.println("Invalid option ");
		}
		
		scanner.close();
	}

}
