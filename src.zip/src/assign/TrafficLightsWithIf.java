package assign;

import java.util.Scanner;

public class TrafficLightsWithIf {

	public static void main(String[] args) {
String option = null;
		
		System.out.println("RED");
		System.out.println("YELLOW");
		System.out.println("GREEN");
		System.out.println("Select light ");
		Scanner scanner = new Scanner(System.in);
		option = scanner.next();
		
		if(option.equalsIgnoreCase("red")) {
			System.out.println("STOP on RED");
		}
		else 
		if(option.equalsIgnoreCase("YELLOW")){
			System.out.println("READY on YELLOW");
		}
		else 
		if(option.equalsIgnoreCase("GREEN")){
			System.out.println("GO on GREEN");
		}
		else {
			System.out.println("Invalid option ");
		}
		scanner.close();

	}

}
