package test;

public class PersonTest {

	public static void main(String[] args) {
//		Person personRef1 = new Person(1,"Rama","Krishna","Hyderabad");
//		
//		personRef1.setId(1234);
//		personRef1.setFirstName("Rama");
//		personRef1.setLastName(new String("Krishna"));
//		personRef1.setAddress("Hyderabad");
//		
//		
//		System.out.println(personRef1.getId());
//		System.out.println(personRef1.getFirstName());
//		System.out.println(personRef1.getLastName());
//		System.out.println(personRef1.getAddress());

//		System.out.println(personRef1);

//		Student studentRef1 = new Student(1, new int[] {0,77});
//		
//		Student studentRef2 = new Student(10, new int[] {45,56,47,65,65});
//		
//		System.out.println(studentRef1);
//		studentRef1.setMarks(new int[] {37,56});
//		System.out.println(studentRef1);
//		
//		System.out.println(studentRef2);
		String str = "proceeding";

		System.out.println(str.charAt(6));

		String numbers = "50 23 28 50";

		System.out.println(greatest(numbers.split(" ")) ? "Yes" : "No");
	}

	static boolean greatest(String scores[]) {

		if (Integer.parseInt(scores[0]) > Integer.parseInt(scores[1])
				&& Integer.parseInt(scores[0]) > Integer.parseInt(scores[2]))
			return true;
		else
			return false;
//			rtnValue = num1;
//		else if (num2 > num1 && num2 > num3)
//			rtnValue = num2;
//		else
//			rtnValue = num3;

	}
}
