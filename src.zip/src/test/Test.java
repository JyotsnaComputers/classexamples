package test;

import java.io.IOException;

class newthread extends Thread {
	Thread t1, t2;

	newthread() {
		t1 = new Thread(this, "Thread_1");
		t2 = new Thread(this, "Thread_2");
		t1.start();
		t2.start();
	}

	public void run() {
		t2.setPriority(Thread.MAX_PRIORITY);
		System.out.print(t1.equals(t2));
	}
}

public class Test {

	public static void main(String[] args) throws IOException {
		String s1 = "Hello";
		String s2 = "World";
		s1.concat(s2);
		System.out.println(s1);
	}

}
