package oops;

public interface Area {
	public static final int CONST = 100;
	public abstract double findArea();
}