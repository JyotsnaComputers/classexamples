package oops;

public class Polygone implements Perimeter {

	@Override
	public double findCircum() {
		// TODO Auto-generated method stub
		return 0;
	}
}