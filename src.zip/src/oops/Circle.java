package oops;

public class Circle extends Shape implements Area, Perimeter {

	@Override
	public double findArea() {
		System.out.println("Area");
		return 0;
	}
	@Override
	public double findCircum() {
		System.out.println("Circum");
		return 0;
	}
}