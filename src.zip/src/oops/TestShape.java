package oops;

public class TestShape {

	public static void main(String[] args) {
		final int MYFIXED_VALUE = 200;
		
		Circle circle = new Circle();

		circle.findArea();
		circle.findCircum();
		System.out.println(circle.toString());

		System.out.println("************");
		Shape cshape = new Circle();
		System.out.println(cshape.toString());
		System.out.println("#######");
		Area acircle = new Circle();
		acircle.findArea();
		System.out.println("&&&&&&&");
		Perimeter pcircle = new Circle();
		pcircle.findCircum();
	}
}