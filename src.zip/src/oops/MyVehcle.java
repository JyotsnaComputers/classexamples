package oops;

public abstract class MyVehcle {
	private int id;
	private String brandName;
	
	public abstract void riddingOnTheWater();
	
	public void riddingOnRoad() {
		System.out.println("Ridding on Road ");
	}
}