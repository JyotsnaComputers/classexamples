package oops;

public class FlyingVechcle extends MyVehcle {

	private String screw;

	@Override
	public void riddingOnTheWater() {
		System.out.println("Water ");	
	}
	
	public void underWater() {
		System.out.println("Under Water ");
	}
	
	public final void simpleMethod() {
		System.out.println("Simple Method ");
	}
}