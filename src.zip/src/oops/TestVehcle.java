package oops;

public class TestVehcle {

	public static void main(String[] args) {
		
		FlyingVechcle flyingVechcle = new FlyingVechcle();
		
		flyingVechcle.riddingOnRoad();
		flyingVechcle.riddingOnTheWater();
		flyingVechcle.underWater();
		System.out.println("********");
		
		FlyingVechcle flyingMachine = new FlyingMachine();
		
//		flyingMachine.fly();
		flyingMachine.riddingOnRoad();
		flyingMachine.riddingOnTheWater();
//		flyingMachine.spaceRidding();
		flyingMachine.underWater();
	}
}