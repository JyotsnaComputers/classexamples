package oops;

public abstract class Shape {
	@Override
	public String toString() {
		return "Shape";
	}
}
