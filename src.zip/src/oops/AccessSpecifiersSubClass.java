package oops;

import demo.AccessSpecifiers;

public class AccessSpecifiersSubClass extends AccessSpecifiers {
	public void show() {
//		priData = 10;
//		defData = 120;
		pubData = 111;
		proData = 222;
	}
}
