package oops;

public class NFM {

}
