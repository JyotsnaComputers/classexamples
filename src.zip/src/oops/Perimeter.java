package oops;

public interface Perimeter {
	double findCircum();
}