package oops;

public class Employee extends Person {
	private double basicSalary;
	public Employee(long id, double basicSalary) {
		super(id);
		this.basicSalary = basicSalary;
	}
	@Override
	public String toString() {
		return "Employee [basicSalary=" + basicSalary + ", Id = " + getId() + ", firstName = " + getFirstName()
				+ ", lastName = " + getLastName() + ", address = " + getAddress() + "]";
	}
}