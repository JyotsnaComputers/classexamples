package oops;

import java.util.Arrays;

public class Student extends Person {
	
//	public Student() {
//		super();
//		System.out.println("Student Default Constructor ");
//	}
	public Student(long id, int[] marks) {
		super(id);
		this.marks = marks;
	}

	private int marks[] = new int[5];

	@Override
	public String toString() {
		return "Student [marks=" + Arrays.toString(marks) + ", Id = " + getId() + ", firstName = "
				+ getFirstName() + ", lastName = " + getLastName() + ", address = " + getAddress() + "]";
	}
	public int[] getMarks() {
		return marks;
	}
	public void setMarks(int[] marks) {
		this.marks = marks;
	}
	@Override
	public String getLastName() {
		return super.getLastName();
	}
}