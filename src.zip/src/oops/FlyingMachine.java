package oops;

public final class FlyingMachine extends FlyingVechcle {
	private double space;
	
	public void fly() {
		System.out.println("Flying ");
	}
	public void spaceRidding() {
		System.out.println("Space ridding ");
	}
	@Override
	public void underWater() {
		System.out.println("New Under Water ");
	}

	public void simpleMethod(int arg) {
		System.out.println("Machine Simple Method ");
	}
}