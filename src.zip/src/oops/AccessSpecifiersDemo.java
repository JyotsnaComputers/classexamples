package oops;

import demo.AccessSpecifiers;

public class AccessSpecifiersDemo {

	public static void main(String[] args) {
		AccessSpecifiers obj = new AccessSpecifiers();
//		System.out.println(obj.defData);
//		System.out.println(obj.proData);
		System.out.println(obj.pubData);
	}

}
