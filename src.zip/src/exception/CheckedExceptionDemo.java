package exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class CheckedExceptionDemo {

	public static void main(String[] args) throws Exception {
		fileHandle();
	}

	static void fileHandle() throws FileNotFoundException {
		FileInputStream fis = null;
		fis = new FileInputStream("f:/test/file.txt");

	}
}