package exception;

import java.util.Scanner;

public class ErrorPrediction {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter a first number ");
		int first = scanner.nextInt();
		
		System.out.println("Enter a second number ");
		int second = scanner.nextInt();
	
		int result = 0;
		try {
		result = first / second;
		}catch(ArithmeticException aex) {
//			System.out.println("Enter a NON ZERO number ");
//			second = scanner.nextInt();
//			result = first / second;
		}
		System.out.println("Result : " + result);
		
		scanner.close();
	}
}