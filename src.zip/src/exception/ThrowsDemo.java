package exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ThrowsDemo {

	public static void main(String[] args) {
		
		try {
			FileInputStream fis =  openFile("file.txt");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(division(5,4));
	}
	
	static FileInputStream openFile(String fileName) throws FileNotFoundException{
		return new FileInputStream(fileName);
	}
	static int division(int first, int second) throws ArithmeticException{
		return first/second;
	}
}