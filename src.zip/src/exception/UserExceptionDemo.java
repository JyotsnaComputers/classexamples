package exception;

public class UserExceptionDemo {

	public static void main(String[] args) {
		try {
			checkEligibility(50);
		} catch (AgeException e) {

		}
	}

	static boolean checkEligibility(int age) throws AgeException {
		boolean eligible = false;
		if (age >= 18) {
			eligible = true;
		} else {
			throw new AgeException("Age must be gr 18 ");
		}

		return eligible;
	}
}