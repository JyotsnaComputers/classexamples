package exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class TryWithReuourcesDemo {
	public static void main(String[] args) {
		try (FileInputStream fis = new FileInputStream("f:/test/file.txt")){
			
		} catch (FileNotFoundException e) {
			
		} catch (IOException e1) {
			
		}finally {
			
		}
	}
}