package exception;

public class CommandLineArgumentsDemo {
	public static void main(String[] args) {
		int result = 0;
		try {
		result = Integer.parseInt(args[0]) / Integer.parseInt(args[1]);
		}catch(NumberFormatException  | ArithmeticException nfex) {
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		System.out.println("Result : " + result);
	}
}