package exception;

public class ExceptionDemo {
	public static void main(String[] args) {
		int result = 0;

		try {
			result = Integer.parseInt(args[0]) / Integer.parseInt(args[1]);
		} catch (ArrayIndexOutOfBoundsException aix) {
			System.out.println("Need at leaset two arguments pls re-enter");

			int num1 = 10;
			int num2 = 5;
			result = num1 / num2;
		} catch (NumberFormatException nfx) {

		} catch (ArithmeticException aex) {
			result = 0;
		} catch (Exception ex) {

		}
		System.out.println("Rsult  " + result);

	}

	static boolean isNumber(String str) {
		boolean rtnValue = true;

		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			switch (ch) {
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				continue;
			default:
				rtnValue = false;
				break;
			}
		}

		return rtnValue;
	}
}