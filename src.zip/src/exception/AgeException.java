package exception;

public class AgeException extends Exception{
	public AgeException(String message) {
		super(message);
	}
}
