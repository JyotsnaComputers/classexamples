package demo;

public class AccessSpecifiers {
	private int priData;
	int defData;
	public int pubData;
	protected int proData;
	
	/*
	 private --- can access within declared class
	 default --- can access within declared package
	 			within subclasses and with objects
	 protected --- can access within declared package
	 			within subclasses and with objects
	 			can access within subclasses in any package.
	 public --- can access within declared package
	 			within subclasses and with objects
	 			can access within subclasses in any package.
	 			can access with objects in any package.
	  
	 */
}