package design;
public class SingletonDemo {
    
    private static final SingletonDemo instance = new SingletonDemo();
    
    //private constructor to avoid client applications to use constructor
    private SingletonDemo(){}

    public static SingletonDemo getInstance(){
        return instance;
    }
    //Lazy
//    public static SingletonDemo getInstance(){
//        if(instance == null){
//            instance = new SingletonDemo();
//        }
//        return instance;
//    }
    //Thread Safe
//    public static synchronized SingletonDemo getInstance(){
//        if(instance == null){
//            instance = new SingletonDemo();
//        }
//        return instance;
    	/*
    	 * if(instance == null){
        synchronized (SingletonDemo.class) {
            if(instance == null){
                instance = new SingletonDemo();
            }
        }
    }
    return instance;
    	 */
//    }
}