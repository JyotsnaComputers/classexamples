package enumd;

public class WeekdaysDemo {
	public static void main(String[] args) {

		Weekdays day = Weekdays.WEDNESDAY;

		switch (day) {
		case MONDAY:
			System.out.println("Today is Monday ");
			break;
		case TUESDAY:
			System.out.println("Today is Tuesday");
			break;
		case WEDNESDAY:
			System.out.println("Today is Wedday");
			break;
		case THURSDAY:
			System.out.println("Today is Thurday");
			break;
		case FRIDAY:
			System.out.println("Today is Friday");
			break;
		default:
			System.out.println("Today is WeekEnd");

		}

		Weekdays[] days = Weekdays.values();

		for (int i = 0; i < days.length; i++) {
			System.out.print(days[i] + "\t");
		}
	}
}