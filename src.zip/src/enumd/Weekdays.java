package enumd;

public enum Weekdays {
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATTURDAY, SUNDAY;
}