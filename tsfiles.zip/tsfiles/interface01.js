var StagePerformer = function (speaker) {
    console.log(speaker.name + ' speaks ' + speaker.language + ' language.');
};
var TestMethod = function (speaker) {
    console.log(speaker.name + ' is testing ' + speaker.language + ' something ');
};
var speaker = {};
speaker.name = 'Patel';
speaker.language = 'Marati';
StagePerformer(speaker);
TestMethod(speaker);
