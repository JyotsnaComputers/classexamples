export {}
let multiVar : number | boolean = 10;

console.log(multiVar);

// multiVar = "string value";
// console.log(multiVar);

multiVar = true;
console.log(multiVar);

let unknown1:undefined = undefined;
let nullable:null = null;

let anyValue: any = 100; console.log(anyValue);
anyValue = "JCT"; console.log(anyValue);
anyValue = true; console.log(anyValue);

let myVar:any = true;
myVar = 10; console.log(myVar.toString());
myVar = true; console.log(myVar);
myVar = "string value"; console.log(myVar);

let unknownVar : unknown;
unknownVar = 1000; console.log(unknownVar);
unknownVar = true; console.log(unknownVar);

console.log((unknownVar as String).charAt(2));
