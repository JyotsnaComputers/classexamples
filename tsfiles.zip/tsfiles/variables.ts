export {}

let isBig: boolean = true;
let sum: number = 100;
let myName:string = "JCT";

let combinedStr: string = `My name is :  + ${myName}` ;


console.log(isBig);
console.log(sum);
console.log(myName);
console.log(combinedStr);

// let num = 100; console.log(num);
// num = true; console.log(num);