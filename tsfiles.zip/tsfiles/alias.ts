export{}

type id =number;
type pname= string;
type pdate= Date;

type genId = number | string;

function emp(eid:id, ename:pname, dob:pdate){
    console.log(eid + " " + ename + " "  + dob);
}
emp(101, 'Rurdra', new Date('2001-Jan-14'));

let gid1:genId = 500; // let gid1:number = 500;
console.log(gid1);
gid1 = 'One'
console.log(gid1);

let gid2:genId = 'seven'; // let gid2:string = 'seven'
console.log(gid2);
gid2 = 123;
console.log(gid2);

let gid3:genId;
gid3 = 234;
gid3 = 'ddd'

type User = {  
    uid : number;
    uname :string;
    address:string;

};
function getDetails(user:User) :void {
    console.log(user.uid + " " + user.uname + " " + user.address);
}

const user:User = {uid:201, uname:'Gyaneshwar', address:'Delhi'};

getDetails(user);