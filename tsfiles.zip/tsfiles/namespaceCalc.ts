namespace calc{  
    export function square(num: number) : number{  
        return num * num;
    }  
}  