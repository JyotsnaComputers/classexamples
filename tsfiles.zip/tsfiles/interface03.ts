interface Person3 {  
    firstName: string;  
    lastName: string;  
    age: number;  
    FullName():string;  
    GetAge():number;  
}  
// implementing the interface  
class Employee3 implements Person3 {  
    firstName: string;  
    lastName: string;  
    age:number;  
    FullName():string {  
        return this.firstName + ' ' + this.lastName;  
    }  
    GetAge() : number {  
        return this.age;  
    }  
    constructor(firstN: string, lastN: string, getAge: number) {  
        this.firstName = firstN;  
        this.lastName = lastN;  
        this.age = getAge;  
    }  
}  
// using the class that implements interface  
let myEmployee = new Employee3('Mahesh', 'Chadra', 27);  
let fullName = myEmployee.FullName();  
let Age = myEmployee.GetAge();  
console.log("Name of Person: " +fullName + '\nAge: ' + Age); 


