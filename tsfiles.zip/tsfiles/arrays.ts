let numarr1:number[] = [1,2,3,4]

let numarr2:Array<number> = [9,8,7,6,5]

for(let obj in numarr1){
    console.log(numarr1[obj]);
}

for(let obj in numarr2){
    console.log(numarr2[obj]);
}
