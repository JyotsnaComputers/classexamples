var empObject = {};
empObject.pname = "Rudraksh";
empObject.age = 25;
empObject.gender = "Male";
empObject.empCode = 3712;
console.log("Name: " + empObject.pname);
console.log("Employee Code: " + empObject.empCode);
var empObject2 = {
    pname: "Mahendra",
    age: 25,
    gender: "Male",
    empCode: 3715,
};
console.log("Name: " + empObject2.pname);
console.log("Employee Code: " + empObject2.empCode);
