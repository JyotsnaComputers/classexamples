export {}

let mydata;
mydata = null; //"Simple String data";

console.log(mydata?.charAt(2));

mydata = 12345.98765;
console.log(mydata.toPrecision(8));
