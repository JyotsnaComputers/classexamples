class Employee {  
    empCode: number;  
    empName: string;  
    empDob: Date;
    constructor(code: number, name: string, dob:Date) {  
            this.empName = name;  
            this.empCode = code;
            this.empDob = dob;
    }  
    getDob() : Date {
        return this.empDob;
    }
    toString() : string {
        return "Employee Code : " + this.empCode +
                "\nEmployee Name : " + this.empName +
                "\nEmployee Dob  : " + this.empDob;
    }
}


let emp = new Employee(101, "Mahesh", new Date("2020-12-17"));

console.log(emp.toString());