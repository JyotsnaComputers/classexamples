"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function print(obj) {
    console.log(obj);
}
var pobj = {};
pobj.title = 'title';
pobj.content = 'content';
pobj.tags = ['tags'];
print(pobj);
var pobj3 = { title: '', content: '', tags: [''] };
var pobj2 = { title: 'obj2', content: 'content' };
print(pobj2);
