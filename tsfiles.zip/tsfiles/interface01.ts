interface Person1 {  
    name: String;  
    language: String;  
} 
interface Tester{
  name: String;  
  language: String;
} 
let StagePerformer = (speaker: Person1) => {  
  console.log(speaker.name + ' speaks ' + speaker.language + ' language.');  
};  

let TestMethod = (speaker: Tester) => {  
  console.log(speaker.name + ' is testing ' + speaker.language + ' something ');  
}
let  speaker = <Person1>{};
speaker.name= 'Patel'
speaker.language = 'Marati'  
StagePerformer(speaker);  
TestMethod(speaker);