"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function emp(eid, ename, dob) {
    console.log(eid + " " + ename + " " + dob);
}
emp(101, 'Rurdra', new Date('2001-Jan-14'));
var gid1 = 500; // let gid1:number = 500;
console.log(gid1);
gid1 = 'One';
console.log(gid1);
var gid2 = 'seven'; // let gid2:string = 'seven'
console.log(gid2);
gid2 = 123;
console.log(gid2);
var gid3;
gid3 = 234;
gid3 = 'ddd';
function getDetails(user) {
    console.log(user.uid + " " + user.uname + " " + user.address);
}
var user = { uid: 201, uname: 'Gyaneshwar', address: 'Delhi' };
getDetails(user);
