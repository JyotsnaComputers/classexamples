export{}

interface Post {
    title: string;
    content: string;
    tags?: string[];
  }
function print(obj:Post){
    console.log(obj)
}
  
  const pobj = <Post>{}
  pobj.title = 'title'
  pobj.content = 'content'
  pobj.tags = ['tags']
  print(pobj)

  let pobj3:Post = {title:'', content:'', tags:['']};

  let pobj2  = {title:'obj2', content:'content'};

  print(pobj2)


