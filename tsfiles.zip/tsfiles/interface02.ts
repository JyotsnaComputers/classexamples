interface Person2 {   
    pname:string    
 }  
 interface PersonDetail2 {   
     age:number  
     gender:string  
 }  
 interface Employee2 extends Person2, PersonDetail2 {   
     empCode:number  
 }  
 let empObject = <Employee2>{};   
 empObject.pname = "Rudraksh"  
 empObject.age = 25   
 empObject.gender = "Male"  
 empObject.empCode = 3712 
 console.log("Name: "+empObject.pname);  
 console.log("Employee Code: "+empObject.empCode); 
 
 let empObject2 = { 
 pname : "Mahendra",  
 age: 25,   
 gender : "Male",  
 empCode: 3715,
 }; 
 console.log("Name: "+empObject2.pname);  
 console.log("Employee Code: "+empObject2.empCode); 
 