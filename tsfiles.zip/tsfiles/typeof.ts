function kiloToPounds(weight :number | string) :number{
    let rtnvalue : number = 0;
    if(typeof weight === 'number' ){
        rtnvalue = weight * 2.2046226;
    }
    if(typeof weight === 'string'){
        rtnvalue = parseFloat(weight) * 2.2046226;
    }
    return rtnvalue;
}