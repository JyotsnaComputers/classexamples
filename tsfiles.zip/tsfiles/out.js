var calc;
(function (calc) {
    function square(num) {
        return num * num;
    }
    calc.square = square;
})(calc || (calc = {}));
///<reference path="namespaceCalc.ts" />
let result = calc.square(11);
console.log(result);
// tsc --target es6  namespaceCalcCall.ts --outfile out.js
