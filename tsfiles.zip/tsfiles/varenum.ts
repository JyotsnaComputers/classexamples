export {}

enum weekdays {MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY}

let today: weekdays = weekdays.MONDAY

console.log(today)

let specific: weekdays = 4
console.log(specific)

enum Services {
    CX_Strategy,
    Experience_Design=4,
    Digital_Engineering,
    Experience_Platforms,
    Automation_Operations,
    Enterprise_Modernization,
    Data_Analytics,
    CX_Management,
    Content }

    let service:Services = Services.Digital_Engineering;
    console.log(service)