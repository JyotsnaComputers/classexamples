export {}

let e1={id:105,name:"Kiran sharma",salary:40000};

function print(arg : any){
    console.log(arg);
}
print(10);
print("Concentrix")
print(true)
print(e1)

console.log("--- My Function ---");
function myFunction<T>(arg:T){
	console.log(arg);
}
myFunction(10);
myFunction(true);
myFunction("Concentrix");
myFunction(e1);



interface Unique{
    id : number;
};
interface Book {
    id : number;
    bname : string;
}
interface Employee {
    id : number;
    ename : string;
    dob : Date;
}
console.log("--- Unique ---")
function sortById(objs : Unique[]){
    return objs.sort((e1, e2)=> e2.id - e1.id);
}
let uobjs:Unique[] = [{id:5},{id:8},{id:3},{id:14},{id:9},{id:21}];
// let sorteu = sortById(uobjs);
// for(let vi in sorteu){
//     console.log(sorteu[vi]);
// }
 let bobjs:Book[] = [{id:101,bname:'Complete Ref'},
 {id:341,bname:'First Head'},
 {id:761,bname:'Biginers Guide'},
 {id:431,bname:'For Dummies'},
 {id:244,bname:'Fundamentals '}];
// let sorteb = sortById(bobjs)
// for(let vi in sorteb){
//     console.log(sorteb[vi]);
// }

let eobjs:Employee[] = [{id:101,ename:'Ramesh',dob:new Date()},
{id:341,ename:'Rupesh',dob:new Date() },
{id:761,ename:'Rajesh',dob:new Date()},
{id:431,ename:'Rakesh',dob:new Date()},
{id:244,ename:'Rudresh',dob:new Date()}]


function sortedBooks(books : Book[]){
    return books.sort((b1, b2)=> b1.id - b2.id);
}

function sortedEmployees(emps : Employee[]){
    return emps.sort((e1, e2)=> e1.id - e2.id);
}

// let sortedEobjs = sortedEmployees(eobjs)
// print(sortedEobjs[0]); 

function sorted<T extends Unique>(list : T[]) {
    return list.sort((o1, o2)=> o1.id - o2.id);
}
let sortedEobjs = sorted(eobjs)
print(sortedEobjs[0].ename); 
let sorteu = sorted(uobjs);

let sorteb = sorted(bobjs)