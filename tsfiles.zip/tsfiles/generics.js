"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var e1 = { id: 105, name: "Kiran sharma", salary: 40000 };
function print(arg) {
    console.log(arg);
}
print(10);
print("Concentrix");
print(true);
print(e1);
console.log("--- My Function ---");
function myFunction(arg) {
    console.log(arg);
}
myFunction(10);
myFunction(true);
myFunction("Concentrix");
myFunction(e1);
;
console.log("--- Unique ---");
function sortById(objs) {
    return objs.sort(function (e1, e2) { return e2.id - e1.id; });
}
var uobjs = [{ id: 5 }, { id: 8 }, { id: 3 }, { id: 14 }, { id: 9 }, { id: 21 }];
// let sorteu = sortById(uobjs);
// for(let vi in sorteu){
//     console.log(sorteu[vi]);
// }
var bobjs = [{ id: 101, bname: 'Complete Ref' },
    { id: 341, bname: 'First Head' },
    { id: 761, bname: 'Biginers Guide' },
    { id: 431, bname: 'For Dummies' },
    { id: 244, bname: 'Fundamentals ' }];
// let sorteb = sortById(bobjs)
// for(let vi in sorteb){
//     console.log(sorteb[vi]);
// }
var eobjs = [{ id: 101, ename: 'Ramesh', dob: new Date() },
    { id: 341, ename: 'Rupesh', dob: new Date() },
    { id: 761, ename: 'Rajesh', dob: new Date() },
    { id: 431, ename: 'Rakesh', dob: new Date() },
    { id: 244, ename: 'Rudresh', dob: new Date() }];
function sortedBooks(books) {
    return books.sort(function (b1, b2) { return b1.id - b2.id; });
}
function sortedEmployees(emps) {
    return emps.sort(function (e1, e2) { return e1.id - e2.id; });
}
// let sortedEobjs = sortedEmployees(eobjs)
// print(sortedEobjs[0]); 
function sorted(list) {
    return list.sort(function (o1, o2) { return o1.id - o2.id; });
}
var sortedEobjs = sorted(eobjs);
print(sortedEobjs[0].ename);
var sorteu = sorted(uobjs);
var sorteb = sorted(bobjs);
