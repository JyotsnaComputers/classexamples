export {}

let say = "Hello JCT"
console.log(say)