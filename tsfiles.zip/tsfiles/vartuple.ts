let contact:[string, number] = ["Mahesh", 9848012345]

// let tupleex:[string, number] = ["str value", 9848012345];//, "another"]
// error

// but any numbers and strings can push 
contact.push(123456)
contact.push("another string")

console.log(contact)

let multipes: (number | string)[] = [2, "two", 4, "four"];

console.log(multipes)