export {}

interface Book {
    btitle : string;
    bsubject : string;
    bauthor : string;
};

interface Book {
    publisher: string;
    price :number;
};

const bookObj:Book = {
    btitle: 'Complete Reference',
    bsubject: 'Java',
    bauthor: 'Herberlt Schildt',
    publisher: 'Tata MGHills',
    price: 450
};

console.log(bookObj);